"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab3_tab3_module_ts"],{

/***/ 9314:
/*!********************************************************!*\
  !*** ./src/app/tab3/datos-usuar/datos-usuar.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatosUsuarModule": () => (/* binding */ DatosUsuarModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _tab3_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../tab3-routing.module */ 9818);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _datos_usuar_datos_usuar_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./datos-usuar/datos-usuar.component */ 7807);








let DatosUsuarModule = class DatosUsuarModule {
};
DatosUsuarModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_datos_usuar_datos_usuar_component__WEBPACK_IMPORTED_MODULE_1__.DatosUsuarComponent],
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _tab3_routing_module__WEBPACK_IMPORTED_MODULE_0__.Tab3PageRoutingModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule,
        ],
        exports: [_datos_usuar_datos_usuar_component__WEBPACK_IMPORTED_MODULE_1__.DatosUsuarComponent]
    })
], DatosUsuarModule);



/***/ }),

/***/ 7807:
/*!***********************************************************************!*\
  !*** ./src/app/tab3/datos-usuar/datos-usuar/datos-usuar.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatosUsuarComponent": () => (/* binding */ DatosUsuarComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _datos_usuar_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./datos-usuar.component.html?ngResource */ 5598);
/* harmony import */ var _datos_usuar_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./datos-usuar.component.scss?ngResource */ 8680);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/app-service.service */ 5703);






let DatosUsuarComponent = class DatosUsuarComponent {
    constructor(appservice, http) {
        this.appservice = appservice;
        this.http = http;
        this.extraerBase64 = ($event) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            return new Promise((resolve) => {
                console.log($event);
                try {
                    const unsafeImg = window.URL.createObjectURL($event);
                    const reader = new FileReader();
                    reader.readAsDataURL($event);
                    reader.onload = () => {
                        resolve({
                            base: reader.result,
                        });
                    };
                    reader.onerror = error => {
                        resolve({
                            base: null,
                        });
                    };
                    return reader;
                }
                catch (e) {
                    return null;
                }
            });
        });
        this.usuario = JSON.parse('{}');
        this.url = this.appservice.url;
        console.log(this.url);
    }
    ngOnInit() { }
    // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
    ngAfterContentInit() {
        this.cargarUsuario();
    }
    handleRefresh(event) {
        setTimeout(() => {
            // Any calls to load data go here
            this.cargarUsuario();
            event.target.complete();
        }, 2000);
    }
    ;
    guardar() {
    }
    cargarUsuario() {
        this.usuario = this.appservice.usuario;
        console.log(this.usuario);
    }
    capturarFile(evento) {
        const archivoCapturado = evento.target.files[0];
        console.log(evento);
        console.log(archivoCapturado);
        this.archivo.nombreArchivo = archivoCapturado.name;
        this.archivos.push(archivoCapturado);
        this.extraerBase64(archivoCapturado).then((imagen) => {
            this.previsualizacion = imagen.base;
            // this.archivo.base64textString = imagen.base;
        });
        if (evento.target.files && archivoCapturado) {
            const reader = new FileReader();
            reader.onload = this.handleReaderLoaded.bind(this);
            reader.readAsBinaryString(archivoCapturado);
        }
    }
    handleReaderLoaded(readerEvent) {
        const binaryString = readerEvent.target.result;
        this.archivo.base64textString = btoa(binaryString);
    }
    subirArchivo(id) {
        try {
            const formularioDeDatos = new FormData();
            this.archivos.forEach(archivo => {
                formularioDeDatos.append('files', archivo);
            });
            this.archivo.nombre = id;
            this.archivo.tipo = 'usuario';
            console.log(this.archivo);
            /*
      
                  this.http.post(this.url + '/proyectodaw/subirfichero.php', this.archivo).subscribe((res: any) => {
      
                    console.log('Respuesta del servidor', res);
      
                  });*/
        }
        catch (e) {
            console.log(e);
        }
    }
};
DatosUsuarComponent.ctorParameters = () => [
    { type: src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__.AppServiceService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient }
];
DatosUsuarComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-datos-usuar',
        template: _datos_usuar_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_datos_usuar_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DatosUsuarComponent);



/***/ }),

/***/ 9818:
/*!*********************************************!*\
  !*** ./src/app/tab3/tab3-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3PageRoutingModule": () => (/* binding */ Tab3PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab3.page */ 2394);




const routes = [
    {
        path: '',
        component: _tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page,
    }
];
let Tab3PageRoutingModule = class Tab3PageRoutingModule {
};
Tab3PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab3PageRoutingModule);



/***/ }),

/***/ 3746:
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3PageModule": () => (/* binding */ Tab3PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab3.page */ 2394);
/* harmony import */ var _tab3_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab3-routing.module */ 9818);
/* harmony import */ var _datos_usuar_datos_usuar_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./datos-usuar/datos-usuar.module */ 9314);








let Tab3PageModule = class Tab3PageModule {
};
Tab3PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule, _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule, _tab3_routing_module__WEBPACK_IMPORTED_MODULE_1__.Tab3PageRoutingModule, _datos_usuar_datos_usuar_module__WEBPACK_IMPORTED_MODULE_2__.DatosUsuarModule],
        declarations: [_tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page],
    })
], Tab3PageModule);



/***/ }),

/***/ 2394:
/*!***********************************!*\
  !*** ./src/app/tab3/tab3.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3Page": () => (/* binding */ Tab3Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab3_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab3.page.html?ngResource */ 9769);
/* harmony import */ var _tab3_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab3.page.scss?ngResource */ 7087);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let Tab3Page = class Tab3Page {
    constructor() { }
};
Tab3Page.ctorParameters = () => [];
Tab3Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-tab3',
        template: _tab3_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tab3_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], Tab3Page);



/***/ }),

/***/ 8680:
/*!************************************************************************************!*\
  !*** ./src/app/tab3/datos-usuar/datos-usuar/datos-usuar.component.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkYXRvcy11c3Vhci5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 7087:
/*!************************************************!*\
  !*** ./src/app/tab3/tab3.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWIzLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 5598:
/*!************************************************************************************!*\
  !*** ./src/app/tab3/datos-usuar/datos-usuar/datos-usuar.component.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-refresher slot=\"fixed\" (ionRefresh)=\"handleRefresh($event)\">\n  <ion-refresher-content></ion-refresher-content>\n</ion-refresher>\n<!--\n\n  <ion-item>\n    <ion-avatar slot=\"start\">\n      <img alt=\"Silhouette of a person's head\"\n      src=\"https://ionicframework.com/docs/img/demos/avatar.svg\" />\n  </ion-avatar>\n  <ion-grid>\n    <ion-row>\n      <ion-label>Nombre: {{usuario.nombre}}</ion-label>\n    </ion-row>\n    <ion-row>\n      <ion-label>Tipo de usuario: {{usuario.rol}}</ion-label>\n    </ion-row>\n  </ion-grid>\n</ion-item>\n\n-->\n\n<ion-grid>\n  <ion-row id=\"centro\">\n    <ion-col size=\"3\">\n    </ion-col>\n    <ion-col size=\"6\" style=\"display: flex;justify-content: center;\">\n      <ion-avatar>\n        <img [src]=\"url+'/proyectoDaw'+usuario.img\" alt=\"\">\n      </ion-avatar>\n    </ion-col>\n    <ion-col size=\"3\">\n    </ion-col>\n  </ion-row>\n</ion-grid>\n\n\n<ion-button>\n  <ion-input type=\"file\" placeholder=\"Awesome Input\"\n    (change)=\"capturarFile($event)\"></ion-input>\n</ion-button>\n<ion-list>\n  <ion-item>\n    <ion-label position=\"floating\" >Nombre</ion-label>\n    <ion-input placeholder=\"Enter text\" [value]=\"usuario.nombre\"></ion-input>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"floating\">Apellidos</ion-label>\n    <ion-input placeholder=\"Enter text\" [value]=\"usuario.nombre\"></ion-input>\n  </ion-item>\n\n  <ion-item>\n    <ion-label position=\"floating\">Contraseña</ion-label>\n    <ion-input type=\"text\" placeholder=\"Enter text\"\n      [value]=\"usuario.contra\"></ion-input>\n  </ion-item>\n\n  <ion-item>\n    <ion-label position=\"floating\">Fecha nacimiento</ion-label>\n    <ion-input type=\"text\" placeholder=\"Enter text\"\n      [value]=\"usuario.fechaNac\"></ion-input>\n  </ion-item>\n\n  <ion-item>\n    <ion-label position=\"floating\">Observaciones</ion-label>\n    <ion-textarea [disabled]=\"true\" placeholder=\"Enter text\"\n      [value]=\"usuario.obs\"></ion-textarea>\n  </ion-item>\n\n  <ion-item>\n    <ion-label position=\"floating\">Email</ion-label>\n    <ion-input type=\"text\" placeholder=\"Enter text\"\n      [value]=\"usuario.email\"></ion-input>\n  </ion-item>\n\n  <ion-item>\n    <ion-label position=\"floating\">Rol</ion-label>\n    <ion-input type=\"text\" placeholder=\"Enter text\"\n      [value]=\"usuario.rol\"></ion-input>\n  </ion-item>\n</ion-list>\n<ion-button (click)=\"guardar()\">\n  <ion-icon slot=\"start\" name=\"add\"></ion-icon>\n  Guardar\n</ion-button>\n";

/***/ }),

/***/ 9769:
/*!************************************************!*\
  !*** ./src/app/tab3/tab3.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Tab 3\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Tab 3</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <app-datos-usuar></app-datos-usuar>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab3_tab3_module_ts.js.map