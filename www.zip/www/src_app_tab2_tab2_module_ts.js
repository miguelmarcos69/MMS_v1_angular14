"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab2_tab2_module_ts"],{

/***/ 8117:
/*!*******************************************************************************!*\
  !*** ./src/app/tab2/mod-carta/anadir-contenido/anadir-contenido.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AnadirContenidoComponent": () => (/* binding */ AnadirContenidoComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _anadir_contenido_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./anadir-contenido.component.html?ngResource */ 2900);
/* harmony import */ var _anadir_contenido_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./anadir-contenido.component.scss?ngResource */ 4885);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/app-service.service */ 5703);








let AnadirContenidoComponent = class AnadirContenidoComponent {
    constructor(http, appService, route) {
        this.http = http;
        this.appService = appService;
        this.route = route;
        this.archivo = {
            nombre: null,
            nombreArchivo: null,
            base64textString: null,
            tipo: null,
        };
        this.extraerBase64 = ($event) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            return new Promise((resolve) => {
                console.log($event);
                try {
                    const unsafeImg = window.URL.createObjectURL($event);
                    const reader = new FileReader();
                    reader.readAsDataURL($event);
                    reader.onload = () => {
                        resolve({
                            base: reader.result,
                        });
                    };
                    reader.onerror = error => {
                        resolve({
                            base: null,
                        });
                    };
                    return reader;
                }
                catch (e) {
                    return null;
                }
            });
        });
        this.archivos = new Array();
        this.anadirPlatosDatos = JSON.parse('{}');
        this.tipo = this.route.snapshot.paramMap.get('tipo');
    }
    ngOnInit() {
        this.load();
    }
    load() {
        this.appService.leerPlatos().subscribe((res) => {
            this.platos = res;
            console.log(this.platos);
        });
        this.appService.leerIngredientes().subscribe((res) => {
            this.ingredientes = res;
            console.log(this.ingredientes);
        });
        this.appService.leerBebida().subscribe((res) => {
            this.bebida = res;
            console.log(this.bebida);
        });
    }
    handleRefresh(event) {
        setTimeout(() => {
            // Any calls to load data go here
            this.load();
            event.target.complete();
        }, 2000);
    }
    ;
    capturarFile(evento) {
        const archivoCapturado = evento.target.files[0];
        console.log(evento);
        console.log(archivoCapturado);
        this.archivo.nombreArchivo = archivoCapturado.name;
        this.archivos.push(archivoCapturado);
        this.extraerBase64(archivoCapturado).then((imagen) => {
            this.previsualizacion = imagen.base;
            // this.archivo.base64textString = imagen.base;
        });
        if (evento.target.files && archivoCapturado) {
            const reader = new FileReader();
            reader.onload = this.handleReaderLoaded.bind(this);
            reader.readAsBinaryString(archivoCapturado);
        }
    }
    handleReaderLoaded(readerEvent) {
        const binaryString = readerEvent.target.result;
        this.archivo.base64textString = btoa(binaryString);
    }
    crear() {
        console.log(this.ingSelec);
        console.log(this.nomSelec);
        const datos = {
            nombre: this.nomSelec,
            ingredientes: this.ingSelec,
            precio: this.precSelec,
            tipo: this.tipo
        };
        this.appService.anadir(datos).subscribe((res) => {
            this.anadirPlatosDatos = res;
            this.subirArchivo(this.anadirPlatosDatos.id);
            this.load();
        });
    }
    subirArchivo(id) {
        try {
            const formularioDeDatos = new FormData();
            this.archivos.forEach(archivo => {
                formularioDeDatos.append('files', archivo);
            });
            this.archivo.nombre = id;
            this.archivo.tipo = this.tipo;
            console.log(this.archivo);
            this.http.post('http://127.0.0.1/proyectodaw/subirfichero.php', this.archivo).subscribe((res) => {
                console.log('Respuesta del servidor', res);
            });
        }
        catch (e) {
            console.log(e);
        }
    }
    cancel() {
        this.modal.dismiss(null, 'cancel');
    }
    confirm() {
        this.modal.dismiss(this.name, 'confirm');
    }
    onWillDismiss(event) {
        const ev = event;
        if (ev.detail.role === 'confirm') {
            this.message = { nombre: ev.detail.data };
            this.appService.anadirIngrediente(this.message).subscribe((res) => {
                this.appService.presentToast('success', 'El incgrediente se ha a�adido corectamente');
                this.load();
            });
        }
    }
};
AnadirContenidoComponent.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient },
    { type: src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__.AppServiceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute }
];
AnadirContenidoComponent.propDecorators = {
    modal: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonModal,] }]
};
AnadirContenidoComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-anadir-contenido',
        template: _anadir_contenido_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_anadir_contenido_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AnadirContenidoComponent);



/***/ }),

/***/ 4787:
/*!****************************************************!*\
  !*** ./src/app/tab2/mod-carta/mod-carta.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModCartaModule": () => (/* binding */ ModCartaModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _tab2_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../tab2-routing.module */ 3092);
/* harmony import */ var _mod_carta_mod_carta_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mod-carta/mod-carta.component */ 5654);
/* harmony import */ var _anadir_contenido_anadir_contenido_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./anadir-contenido/anadir-contenido.component */ 8117);
/* harmony import */ var src_app_tab2_mod_carta_modificar_menu_modificar_menu_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/tab2/mod-carta/modificar-menu/modificar-menu.component */ 6072);










let ModCartaModule = class ModCartaModule {
};
ModCartaModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_mod_carta_mod_carta_component__WEBPACK_IMPORTED_MODULE_1__.ModCartaComponent, _anadir_contenido_anadir_contenido_component__WEBPACK_IMPORTED_MODULE_2__.AnadirContenidoComponent, src_app_tab2_mod_carta_modificar_menu_modificar_menu_component__WEBPACK_IMPORTED_MODULE_3__.ModificarMenuComponent],
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _tab2_routing_module__WEBPACK_IMPORTED_MODULE_0__.Tab2PageRoutingModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClientModule,
        ],
        exports: [_mod_carta_mod_carta_component__WEBPACK_IMPORTED_MODULE_1__.ModCartaComponent],
    })
], ModCartaModule);



/***/ }),

/***/ 5654:
/*!*****************************************************************!*\
  !*** ./src/app/tab2/mod-carta/mod-carta/mod-carta.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModCartaComponent": () => (/* binding */ ModCartaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _mod_carta_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mod-carta.component.html?ngResource */ 3665);
/* harmony import */ var _mod_carta_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mod-carta.component.scss?ngResource */ 1037);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_comandas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/comandas.service */ 7914);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/app-service.service */ 5703);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);








let ModCartaComponent = class ModCartaComponent {
    constructor(comandasService, route, router, appService) {
        this.comandasService = comandasService;
        this.route = route;
        this.router = router;
        this.appService = appService;
        this.archivo = {
            nombre: null,
            nombreArchivo: null,
            base64textString: null
        };
        this.modificarC = JSON.parse('{}');
        this.archivos = new Array();
        this.segment = 'platos';
        this.url = this.appService.url;
        this.prev2 = true;
        this.prev = false;
    }
    ngOnInit() {
        this.load();
    }
    load() {
        this.comandasService.leerPlatos().subscribe((res) => {
            this.platos = res;
            console.log(this.platos);
        });
        this.comandasService.leerIngredientes().subscribe((res) => {
            this.ingredientes = res;
            console.log(this.ingredientes);
        });
        this.comandasService.leerBebida().subscribe((res) => {
            this.bebida = res;
            console.log(this.bebida);
        });
    }
    handleRefresh(event) {
        setTimeout(() => {
            // Any calls to load data go here
            this.load();
            event.target.complete();
        }, 2000);
    }
    ;
    segmentChanged(a) {
        console.log(a.detail.value);
        this.segment = a.detail.value;
    }
    andirBebida() {
        this.router.navigate(['anadirCarta', 'bebida'], { relativeTo: this.route });
    }
    andirPlatos() {
        this.router.navigate(['anadirCarta', 'platos'], { relativeTo: this.route });
    }
    modificar(tipo, a) {
        this.router.navigate(['modificar', tipo, a.id], { relativeTo: this.route });
    }
    cancel() {
        this.modal.dismiss(null, 'cancel');
    }
    confirm() {
        this.modal.dismiss('confirm');
    }
    onWillDismiss(event) {
        const ev = event;
        if (ev.detail.role === 'confirm') {
        }
    }
};
ModCartaComponent.ctorParameters = () => [
    { type: src_app_services_comandas_service__WEBPACK_IMPORTED_MODULE_2__.ComandasService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_3__.AppServiceService }
];
ModCartaComponent.propDecorators = {
    modal: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonModal,] }]
};
ModCartaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-mod-carta',
        template: _mod_carta_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mod_carta_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModCartaComponent);



/***/ }),

/***/ 6072:
/*!***************************************************************************!*\
  !*** ./src/app/tab2/mod-carta/modificar-menu/modificar-menu.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModificarMenuComponent": () => (/* binding */ ModificarMenuComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _modificar_menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modificar-menu.component.html?ngResource */ 8196);
/* harmony import */ var _modificar_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modificar-menu.component.scss?ngResource */ 1178);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/app-service.service */ 5703);
/* harmony import */ var src_app_services_comandas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/comandas.service */ 7914);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);









let ModificarMenuComponent = class ModificarMenuComponent {
    constructor(comandasService, route, router, http, appService) {
        this.comandasService = comandasService;
        this.route = route;
        this.router = router;
        this.http = http;
        this.appService = appService;
        this.archivo = {
            nombre: null,
            nombreArchivo: null,
            base64textString: null,
            tipo: null
        };
        this.extraerBase64 = ($event) => (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            return new Promise((resolve) => {
                console.log($event);
                try {
                    const unsafeImg = window.URL.createObjectURL($event);
                    const reader = new FileReader();
                    reader.readAsDataURL($event);
                    reader.onload = () => {
                        resolve({
                            base: reader.result,
                        });
                    };
                    reader.onerror = error => {
                        resolve({
                            base: null,
                        });
                    };
                    return reader;
                }
                catch (e) {
                    return null;
                }
            });
        });
        this.dato = JSON.parse('{}');
        this.anadirPlatosDatos = JSON.parse('{}');
        this.archivos = new Array();
        this.url = this.appService.url;
        this.prev2 = false;
        this.prev = true;
        this.tipo = this.route.snapshot.paramMap.get('tipo');
        this.id = this.route.snapshot.paramMap.get('id');
    }
    ngOnInit() {
        this.load();
    }
    handleRefresh(event) {
        setTimeout(() => {
            // Any calls to load data go here
            this.load();
            event.target.complete();
        }, 2000);
    }
    ;
    onClick(ing, idPlato) {
        let i = 0;
        this.dato.ingredientes.forEach(element => {
            if (ing.id === element.id) {
                this.dato.ingredientes.splice(i, 1);
            }
            i++;
        });
    }
    ;
    anadirIng() {
        this.ingSelec.forEach(ing => {
            this.ingredientes.forEach(todIngr => {
                if (todIngr.id === ing) {
                    let existe = false;
                    this.dato.ingredientes.forEach(datIng => {
                        console.log();
                        if (datIng.id === ing) {
                            existe = true;
                        }
                        console.log(existe);
                    });
                    if (!existe) {
                        this.dato.ingredientes.push(todIngr);
                    }
                }
            });
        });
    }
    load() {
        if (this.tipo === 'bebida') {
            this.comandasService.leerBebida().subscribe((res) => {
                this.bebida = res;
                console.log(this.bebida);
                this.bebida.forEach(element => {
                    if (this.id === element.id) {
                        this.dato = element;
                        this.nomSelec = this.dato.nombre;
                        this.previsualizacion = this.dato.img;
                        this.precSelec = this.dato.precio;
                        console.log(this.dato);
                    }
                });
            });
        }
        if (this.tipo === 'platos') {
            this.comandasService.leerPlatos().subscribe((res) => {
                this.platos = res;
                console.log(this.platos);
                this.platos.forEach(element => {
                    if (this.id === element.id) {
                        this.dato = element;
                        this.nomSelec = this.dato.nombrePlato;
                        this.previsualizacion = this.dato.img;
                        this.precSelec = this.dato.precio;
                        console.log(this.dato);
                    }
                });
            });
            this.comandasService.leerIngredientes().subscribe((res) => {
                this.ingredientes = res;
                console.log(this.ingredientes);
            });
        }
    }
    capturarFile(evento) {
        const archivoCapturado = evento.target.files[0];
        console.log(evento);
        console.log(archivoCapturado);
        this.archivo.nombreArchivo = archivoCapturado.name;
        this.archivos.push(archivoCapturado);
        this.extraerBase64(archivoCapturado).then((imagen) => {
            this.previsualizacion = imagen.base;
            this.prev = false;
            this.prev2 = true;
            // this.archivo.base64textString = imagen.base;
        });
        if (evento.target.files && archivoCapturado) {
            const reader = new FileReader();
            reader.onload = this.handleReaderLoaded.bind(this);
            reader.readAsBinaryString(archivoCapturado);
        }
    }
    handleReaderLoaded(readerEvent) {
        const binaryString = readerEvent.target.result;
        this.archivo.base64textString = btoa(binaryString);
    }
    modificar() {
        const ing = [];
        if (this.dato.ingredientes) {
            this.dato.ingredientes.forEach(element => {
                ing.push(element.id);
            });
        }
        const datos = {
            id: this.dato.id,
            nombre: this.nomSelec,
            ingredientes: ing,
            precio: this.precSelec,
            tipo: this.tipo
        };
        console.log(datos);
        this.appService.modificarPlatos(datos).subscribe((res) => {
            this.anadirPlatosDatos = res;
            console.log(this.anadirPlatosDatos);
            this.subirArchivo(this.anadirPlatosDatos.id);
            //this.load();
        });
    }
    subirArchivo(id) {
        try {
            const formularioDeDatos = new FormData();
            this.archivos.forEach(archivo => {
                formularioDeDatos.append('files', archivo);
            });
            this.archivo.nombre = id;
            this.archivo.tipo = this.tipo;
            console.log(this.archivo);
            if (this.archivo.nombreArchivo !== null) {
                this.http.post(this.url + '/proyectoDaw/subirfichero.php', this.archivo).subscribe((res) => {
                    console.log('Respuesta del servidor', res);
                    this.appService.presentToast('success', 'Se ha modificado correctamente');
                });
            }
            else {
                console.log('no hay foto');
            }
        }
        catch (e) {
            console.log(e);
        }
    }
    cancel() {
        this.modal.dismiss(null, 'cancel');
    }
    confirm() {
        this.modal.dismiss(this.name, 'confirm');
    }
    onWillDismiss(event) {
        const ev = event;
        if (ev.detail.role === 'confirm') {
            this.message = { nombre: ev.detail.data };
            this.appService.anadirIngrediente(this.message).subscribe((res) => {
                this.appService.presentToast('success', 'El incgrediente se ha a�adido corectamente');
                this.load();
            });
        }
    }
};
ModificarMenuComponent.ctorParameters = () => [
    { type: src_app_services_comandas_service__WEBPACK_IMPORTED_MODULE_3__.ComandasService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__.AppServiceService }
];
ModificarMenuComponent.propDecorators = {
    modal: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonModal,] }]
};
ModificarMenuComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-modificar-menu',
        template: _modificar_menu_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_modificar_menu_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModificarMenuComponent);



/***/ }),

/***/ 3092:
/*!*********************************************!*\
  !*** ./src/app/tab2/tab2-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageRoutingModule": () => (/* binding */ Tab2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _mod_carta_modificar_menu_modificar_menu_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mod-carta/modificar-menu/modificar-menu.component */ 6072);
/* harmony import */ var _mod_carta_anadir_contenido_anadir_contenido_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mod-carta/anadir-contenido/anadir-contenido.component */ 8117);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab2.page */ 442);






const routes = [
    {
        path: '',
        component: _tab2_page__WEBPACK_IMPORTED_MODULE_2__.Tab2Page,
    },
    {
        path: 'anadirCarta/:tipo',
        component: _mod_carta_anadir_contenido_anadir_contenido_component__WEBPACK_IMPORTED_MODULE_1__.AnadirContenidoComponent,
    },
    {
        path: 'modificar/:tipo/:id',
        component: _mod_carta_modificar_menu_modificar_menu_component__WEBPACK_IMPORTED_MODULE_0__.ModificarMenuComponent,
    }
];
let Tab2PageRoutingModule = class Tab2PageRoutingModule {
};
Tab2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
    })
], Tab2PageRoutingModule);



/***/ }),

/***/ 4608:
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageModule": () => (/* binding */ Tab2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page */ 442);
/* harmony import */ var _tab2_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab2-routing.module */ 3092);
/* harmony import */ var _mod_carta_mod_carta_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mod-carta/mod-carta.module */ 4787);








let Tab2PageModule = class Tab2PageModule {
};
Tab2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _tab2_routing_module__WEBPACK_IMPORTED_MODULE_1__.Tab2PageRoutingModule,
            _mod_carta_mod_carta_module__WEBPACK_IMPORTED_MODULE_2__.ModCartaModule
        ],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_0__.Tab2Page],
    })
], Tab2PageModule);



/***/ }),

/***/ 442:
/*!***********************************!*\
  !*** ./src/app/tab2/tab2.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2Page": () => (/* binding */ Tab2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab2_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page.html?ngResource */ 1748);
/* harmony import */ var _tab2_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab2.page.scss?ngResource */ 1597);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let Tab2Page = class Tab2Page {
    constructor() { }
};
Tab2Page.ctorParameters = () => [];
Tab2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-tab2',
        template: _tab2_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tab2_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], Tab2Page);



/***/ }),

/***/ 4885:
/*!********************************************************************************************!*\
  !*** ./src/app/tab2/mod-carta/anadir-contenido/anadir-contenido.component.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "#prev {\n  width: 100px;\n  height: 100px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFuYWRpci1jb250ZW5pZG8uY29tcG9uZW50LnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxNaWd1ZWwlMjBNYXJjb3NcXERlc2t0b3BcXFByb3llY3RvREFXXFxhcHAtMVxcc3JjXFxhcHBcXHRhYjJcXG1vZC1jYXJ0YVxcYW5hZGlyLWNvbnRlbmlkb1xcYW5hZGlyLWNvbnRlbmlkby5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FDQ0YiLCJmaWxlIjoiYW5hZGlyLWNvbnRlbmlkby5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNwcmV2IHtcclxuICB3aWR0aDogMTAwcHg7XHJcbiAgaGVpZ2h0OiAxMDBweDtcclxufVxyXG4iLCIjcHJldiB7XG4gIHdpZHRoOiAxMDBweDtcbiAgaGVpZ2h0OiAxMDBweDtcbn0iXX0= */";

/***/ }),

/***/ 1037:
/*!******************************************************************************!*\
  !*** ./src/app/tab2/mod-carta/mod-carta/mod-carta.component.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = ".img {\n  width: 340px;\n  height: 300px;\n  background-image: no-repeat;\n  background-image: fixed;\n  background-image: center;\n  background-size: cover;\n}\n\n.fondoImagen {\n  height: 300px;\n  background-repeat: no-repeat;\n  background-attachment: fixed;\n  background-position: center center;\n  background-size: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vZC1jYXJ0YS5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXE1pZ3VlbCUyME1hcmNvc1xcRGVza3RvcFxcUHJveWVjdG9EQVdcXGFwcC0xXFxzcmNcXGFwcFxcdGFiMlxcbW9kLWNhcnRhXFxtb2QtY2FydGFcXG1vZC1jYXJ0YS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSx1QkFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7QUNDRjs7QURFQTtFQUNFLGFBQUE7RUFDQSw0QkFBQTtFQUNBLDRCQUFBO0VBQ0Esa0NBQUE7RUFDQSxzQkFBQTtBQ0NGIiwiZmlsZSI6Im1vZC1jYXJ0YS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pbWcge1xyXG4gIHdpZHRoOiAzNDBweDtcclxuICBoZWlnaHQ6IDMwMHB4O1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vLXJlcGVhdDtcclxuICBiYWNrZ3JvdW5kLWltYWdlOiBmaXhlZDtcclxuICBiYWNrZ3JvdW5kLWltYWdlOiBjZW50ZXI7XHJcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxufVxyXG5cclxuLmZvbmRvSW1hZ2VuIHtcclxuICBoZWlnaHQ6IDMwMHB4O1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgYmFja2dyb3VuZC1hdHRhY2htZW50OiBmaXhlZDtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbn1cclxuIiwiLmltZyB7XG4gIHdpZHRoOiAzNDBweDtcbiAgaGVpZ2h0OiAzMDBweDtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLWltYWdlOiBmaXhlZDtcbiAgYmFja2dyb3VuZC1pbWFnZTogY2VudGVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4uZm9uZG9JbWFnZW4ge1xuICBoZWlnaHQ6IDMwMHB4O1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLWF0dGFjaG1lbnQ6IGZpeGVkO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufSJdfQ== */";

/***/ }),

/***/ 1178:
/*!****************************************************************************************!*\
  !*** ./src/app/tab2/mod-carta/modificar-menu/modificar-menu.component.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RpZmljYXItbWVudS5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 1597:
/*!************************************************!*\
  !*** ./src/app/tab2/tab2.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWIyLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 2900:
/*!********************************************************************************************!*\
  !*** ./src/app/tab2/mod-carta/anadir-contenido/anadir-contenido.component.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n      <ion-back-button>Mesa</ion-back-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\" id=\"fondo\">\n\n  <ion-grid>\n    <ion-row id=\"centro\">\n      <ion-col size=\"3\">\n      </ion-col>\n      <ion-col size=\"6\">\n        <img src=\"../../../../assets/logos/logo2.png\" alt=\"\">\n      </ion-col>\n      <ion-col size=\"3\">\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"handleRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n  <ion-list *ngIf=\"tipo==='platos'\">\n    <ion-item>\n      <ion-label position=\"stacked\">Nombre del plato</ion-label>\n      <ion-input [clearInput]=\"true\" [(ngModel)]=\"nomSelec\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Ingredientes</ion-label>\n      <ion-select placeholder=\"Introduce ingredientes\" [(ngModel)]=\"ingSelec\"\n        [multiple]=\"true\">\n        <ion-select-option *ngFor=\"let ing of ingredientes\" [value]=\"ing.id\">{{ing.nombre}}</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Precio</ion-label>\n      <ion-input type=\"number\" [clearInput]=\"true\" [(ngModel)]=\"precSelec\"></ion-input>\n    </ion-item>\n    <ion-img [src]=\"previsualizacion\" id='pev'></ion-img>\n    <ion-input type=\"file\" placeholder=\"Awesome Input\"\n      (change)=\"capturarFile($event)\"></ion-input>\n    <ion-button id=\"open-modal\" expand=\"block\">Añadir ingrediente</ion-button>\n    <ion-button (click)=\"crear()\" expand=\"block\" shape=\"round\">\n      Crear\n    </ion-button>\n  </ion-list>\n  <ion-list *ngIf=\"tipo==='bebida'\">\n    <ion-item>\n      <ion-label position=\"stacked\">Nombre de la bebida</ion-label>\n      <ion-input [clearInput]=\"true\" [(ngModel)]=\"nomSelec\"></ion-input>\n    </ion-item>\n\n    <ion-item>\n      <ion-label position=\"stacked\">Precio</ion-label>\n      <ion-input type=\"number\" [clearInput]=\"true\" [(ngModel)]=\"precSelec\"></ion-input>\n    </ion-item>\n\n  <ion-img [src]=\"previsualizacion\" id='pev'></ion-img>\n\n    <ion-input type=\"file\" placeholder=\"Awesome Input\"\n      (change)=\"capturarFile($event)\"></ion-input>\n    <ion-button (click)=\"crear()\" expand=\"block\" shape=\"round\">\n      Crear\n    </ion-button>\n  </ion-list>\n\n\n  <ion-modal trigger=\"open-modal\" (willDismiss)=\"onWillDismiss($event)\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-buttons slot=\"start\">\n            <ion-button (click)=\"cancel()\">Cancel</ion-button>\n          </ion-buttons>\n          <ion-title>Añadir ingrediente</ion-title>\n          <ion-buttons slot=\"end\">\n            <ion-button (click)=\"confirm()\" [strong]=\"true\">Confirm</ion-button>\n          </ion-buttons>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content class=\"ion-padding\">\n        <ion-item>\n          <ion-label position=\"stacked\">Introdice el nomnbre el ingrediente</ion-label>\n          <ion-input type=\"text\" placeholder=\"Your name\" [(ngModel)]=\"name\"></ion-input>\n        </ion-item>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n</ion-content>\n";

/***/ }),

/***/ 3665:
/*!******************************************************************************!*\
  !*** ./src/app/tab2/mod-carta/mod-carta/mod-carta.component.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "<ion-refresher slot=\"fixed\" (ionRefresh)=\"handleRefresh($event)\">\n  <ion-refresher-content></ion-refresher-content>\n</ion-refresher>\n<ion-content class=\"ion-padding\">\n\n  <ion-grid>\n    <ion-row id=\"centro\">\n      <ion-col size=\"3\">\n      </ion-col>\n      <ion-col size=\"6\">\n        <img src=\"../../../../assets/logos/logo2.png\" alt=\"\">\n      </ion-col>\n      <ion-col size=\"3\">\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-segment (ionChange)=\"segmentChanged($event)\" value=\"platos\">\n    <ion-segment-button value=\"platos\">\n      Platos\n    </ion-segment-button>\n    <ion-segment-button value=\"bebida\">\n      Bebidas\n    </ion-segment-button>\n  </ion-segment>\n\n  <div *ngIf=\"segment==='platos'\">\n    <ion-button (click)=\"andirPlatos()\" expand=\"block\"\n      shape=\"round\">\n      Nuevo\n    </ion-button>\n    <ion-card *ngFor=\"let p of platos\" id=\"{{p.id}}\"\n      style=\"background-image:linear-gradient(rgba(0, 0, 0), rgba(0, 0, 0,\n      0.5)), url('{{url}}/proyectoDaw{{p.img}}');\"\n      class=\"fondoImagen\">\n\n      <ion-card-header>\n        <ion-card-title>{{p.nombrePlato}}</ion-card-title>\n        <ion-card-subtitle>Precio: {{p.precio}} €</ion-card-subtitle>\n        <ion-button id=\"open-modal\" (click)=\"modificar('platos',p)\">\n          <ion-icon slot=\"start\" name=\"add\"></ion-icon>\n          Modificar\n        </ion-button>\n      </ion-card-header>\n      <ion-card-content>\n        <ion-grid>\n\n          <ion-row>\n            <ion-chip *ngFor=\"let ing of p.ingredientes\" color=\"dark\">\n              <ion-label>{{ing.nombre}}</ion-label>\n              <ion-icon name=\"trash-outline\"></ion-icon>\n            </ion-chip>\n\n          </ion-row>\n        </ion-grid>\n      </ion-card-content>\n    </ion-card>\n  </div>\n  <div *ngIf=\"segment==='bebida'\">\n    <ion-button (click)=\"andirBebida()\" expand=\"block\"\n      shape=\"round\">\n      Nuevo\n    </ion-button>\n    <ion-card *ngFor=\"let b of bebida;index as i\" id=\"{{b.id}}\"\n      style=\"background-image: linear-gradient(rgba(0, 0, 0), rgba(0, 0, 0,\n      0.5)), url('{{url}}/proyectoDaw{{b.img}}');\"\n      class=\"fondoImagen\">\n      <ion-card-header>\n\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\">\n              <ion-card-title>{{b.nombre}}</ion-card-title>\n              <ion-card-subtitle>Precio: {{b.precio}} €</ion-card-subtitle>\n              <ion-button id=\"open-modal\" (click)=\"modificar('bebida',b)\">Modificar</ion-button>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-card-header>\n\n    </ion-card>\n  </div>\n";

/***/ }),

/***/ 8196:
/*!****************************************************************************************!*\
  !*** ./src/app/tab2/mod-carta/modificar-menu/modificar-menu.component.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Modidicar</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content class=\"ion-padding\">\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"handleRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n\n  <ion-grid>\n    <ion-row id=\"centro\">\n      <ion-col size=\"3\">\n      </ion-col>\n      <ion-col size=\"6\">\n        <img src=\"../../../../assets/logos/logo2.png\" alt=\"\">\n      </ion-col>\n      <ion-col size=\"3\">\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-list *ngIf=\"tipo==='platos'\">\n\n    <ion-item>\n      <ion-label position=\"stacked\">Nombre del plato</ion-label>\n      <ion-input [clearInput]=\"true\" [(ngModel)]=\"nomSelec\"></ion-input>\n    </ion-item>\n\n    <ion-item>\n      <ion-grid>\n\n        <ion-row>\n          <ion-chip *ngFor=\"let ing of dato.ingredientes\" color=\"dark\">\n            <ion-label>{{ing.nombre}}</ion-label>\n            <ion-icon name=\"trash-outline\" (click)=\"onClick(ing,dato.id)\"></ion-icon>\n          </ion-chip>\n\n        </ion-row>\n      </ion-grid>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Añadir ingredientes</ion-label>\n\n      <ion-select placeholder=\"Introduce ingredientes\"\n        [(ngModel)]=\"ingSelec\"\n        [multiple]=\"true\"\n        (ngModelChange)=\"anadirIng()\">\n        <ion-select-option *ngFor=\"let ing of ingredientes\"\n          [value]=\"ing.id\" selected>{{ing.nombre}}</ion-select-option>\n      </ion-select>\n    </ion-item>\n\n    <ion-item>\n      <ion-label position=\"stacked\">Precio</ion-label>\n      <ion-input type=\"number\" [clearInput]=\"true\"\n        [(ngModel)]=\"precSelec\" [value]=\"dato.precio\"></ion-input>\n    </ion-item>\n\n\n    <img *ngIf=\"prev\" [src]=\"url + '/proyectoDaw/'+previsualizacion\" id='pev'>\n    <img *ngIf=\"prev2\" [src]=\"previsualizacion\" id='pev'>\n    <ion-item>\n      <ion-input type=\"file\" placeholder=\"Awesome Input\"\n        (change)=\"capturarFile($event)\"></ion-input>\n    </ion-item>\n    <ion-button id=\"open-modal\" expand=\"block\">Añadir ingrediente</ion-button>\n    <ion-button (click)=\"modificar()\" expand=\"block\">\n      Modidicar plato\n    </ion-button>\n\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo==='bebida'\">\n\n    <ion-item>\n      <ion-label position=\"stacked\">Nombre de la bebida</ion-label>\n      <ion-input [clearInput]=\"true\" [(ngModel)]=\"nomSelec\"></ion-input>\n    </ion-item>\n\n    <ion-item>\n      <ion-label position=\"stacked\">Precio</ion-label>\n      <ion-input type=\"number\" [clearInput]=\"true\"\n        [(ngModel)]=\"precSelec\"></ion-input>\n    </ion-item>\n\n\n    <img *ngIf=\"prev\" [src]=\"url + previsualizacion\" id='pev'>\n    <img *ngIf=\"prev2\" [src]=\"previsualizacion\" id='pev'>\n    <ion-item>\n      <ion-input type=\"file\" placeholder=\"Awesome Input\"\n        (change)=\"capturarFile($event)\"></ion-input>\n    </ion-item>\n\n    <ion-button (click)=\"modificar()\" expand=\"block\">\n      Modidicar plato\n    </ion-button>\n  </ion-list>\n\n\n\n  <ion-modal trigger=\"open-modal\" (willDismiss)=\"onWillDismiss($event)\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-buttons slot=\"start\">\n            <ion-button (click)=\"cancel()\">Cancel</ion-button>\n          </ion-buttons>\n          <ion-title>Añadir ingrediente</ion-title>\n          <ion-buttons slot=\"end\">\n            <ion-button (click)=\"confirm()\" [strong]=\"true\">Confirm</ion-button>\n          </ion-buttons>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content class=\"ion-padding\">\n        <ion-item>\n          <ion-label position=\"stacked\">Introdice el nomnbre el ingrediente</ion-label>\n          <ion-input type=\"text\" placeholder=\"Your name\" [(ngModel)]=\"name\"></ion-input>\n        </ion-item>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n</ion-content>\n";

/***/ }),

/***/ 1748:
/*!************************************************!*\
  !*** ./src/app/tab2/tab2.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Tab 2\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Tab 2</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <app-mod-carta></app-mod-carta>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab2_tab2_module_ts.js.map