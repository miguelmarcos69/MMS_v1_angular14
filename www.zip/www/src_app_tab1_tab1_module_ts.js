"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab1_tab1_module_ts"],{

/***/ 1497:
/*!********************************************!*\
  !*** ./src/app/config/config.component.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfigComponent": () => (/* binding */ ConfigComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _config_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./config.component.html?ngResource */ 8868);
/* harmony import */ var _config_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./config.component.scss?ngResource */ 662);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_app_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/app-service.service */ 5703);






let ConfigComponent = class ConfigComponent {
    constructor(appservice) {
        this.appservice = appservice;
        this.usuSelect = JSON.parse('{}');
        this.usuarios = JSON.parse('{}');
    }
    ngOnInit() {
        this.load();
    }
    load() {
        this.appservice.leerMesas().subscribe((res) => {
            this.mesas = res;
        });
        this.appservice.datosUsuarios().subscribe((res) => {
            this.usuarios = res;
        });
    }
    cancel() {
        this.modal.dismiss(null, 'cancel');
    }
    confirm() {
        this.modal.dismiss(null, 'confirm');
    }
    onWillDismiss(event) {
        const ev = event;
        if (ev.detail.role === 'confirm') {
            this.appservice.modificarUsuSelec(this.usuSelect).subscribe((res) => {
                if (res.valido) {
                    this.usuSelect = {};
                    this.load();
                    this.appservice.presentToast('success', 'Se ha modificado correctamente');
                }
            });
        }
    }
};
ConfigComponent.ctorParameters = () => [
    { type: _services_app_service_service__WEBPACK_IMPORTED_MODULE_2__.AppServiceService }
];
ConfigComponent.propDecorators = {
    modal: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonModal,] }]
};
ConfigComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-config',
        template: _config_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_config_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ConfigComponent);



/***/ }),

/***/ 8458:
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _login_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.component.html?ngResource */ 2010);
/* harmony import */ var _login_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.component.scss?ngResource */ 9444);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/login.service */ 4120);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 2425);
/* harmony import */ var _tab1_comandas_comandas_comandas_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../tab1/comandas/comandas/comandas.component */ 7020);
/* harmony import */ var _services_app_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/app-service.service */ 5703);









let LoginComponent = class LoginComponent {
    constructor(applogin, route, appservice) {
        this.applogin = applogin;
        this.route = route;
        this.appservice = appservice;
        this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subscription();
    }
    ngOnInit() {
        this.respuesta = JSON.parse('{}');
    }
    onLogin() {
        const formValue = { username: this.nombre, password: this.contra, role: this.role };
        this.subscription.add(this.applogin.login(formValue).subscribe((res) => {
            this.respuesta = res;
            if (this.respuesta.valido) {
                this.appservice.presentToast('success', 'Usuario logueado');
                window.location.reload();
            }
            else {
                //si fallas en el logueo
                this.applogin.logout();
                this.appservice.presentToast('danger', (this.respuesta.msg));
            }
        }));
    }
};
LoginComponent.ctorParameters = () => [
    { type: _services_login_service__WEBPACK_IMPORTED_MODULE_2__.LoginService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute },
    { type: _services_app_service_service__WEBPACK_IMPORTED_MODULE_4__.AppServiceService }
];
LoginComponent.propDecorators = {
    comandas: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild, args: [_tab1_comandas_comandas_comandas_component__WEBPACK_IMPORTED_MODULE_3__.ComandasComponent,] }]
};
LoginComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-login',
        template: _login_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_login_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginComponent);



/***/ }),

/***/ 4120:
/*!*******************************************!*\
  !*** ./src/app/services/login.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginService": () => (/* binding */ LoginService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 4505);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 6587);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 6942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 7418);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @auth0/angular-jwt */ 4467);
/* harmony import */ var _comandas_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./comandas.service */ 7914);
/* harmony import */ var _app_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-service.service */ 5703);









const helper = new _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_2__.JwtHelperService();
let LoginService = class LoginService {
    constructor(http, comandasService, appService, router) {
        this.http = http;
        this.comandasService = comandasService;
        this.appService = appService;
        this.router = router;
        this.loggedIn = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject(true);
        this.url = this.appService.url;
        this.checkToken();
    }
    get isLogged() {
        return this.loggedIn.asObservable();
    }
    login(authData) {
        console.log(authData);
        return this.http
            .post(this.url + '/proyectoDAW/login.php', authData)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((user) => {
            this.saveLocalStorage(user);
            this.loggedIn.next(true);
            console.log(user);
            return user;
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((err) => this.handlerError(err)));
    }
    logout() {
        localStorage.removeItem('token');
        this.loggedIn.next(false);
    }
    checkToken() {
        const userToken = localStorage.getItem('token');
        const isExpired = helper.isTokenExpired(userToken);
        console.log(isExpired);
        //si devuelve false significa que sigue logueado, si es true necesita loguearse
        if (isExpired) {
            this.logout();
        }
        else {
            const user = helper.decodeToken(userToken);
            console.log(user);
            this.appService.mostrarDatosUsuario(user.data).subscribe((res) => {
                this.appService.setUsuario(res);
                console.log(this.appService.getUsuario());
                this.router.navigate(['/tabs/tab1']);
            });
            this.loggedIn.next(true);
        }
    }
    saveLocalStorage(user) {
        const { id, nombre, token } = user;
        localStorage.setItem('token', JSON.stringify(token));
    }
    handlerError(err) {
        let errorMessage = 'An errror occured retrienving data';
        if (err) {
            errorMessage = `Error: code ${err.message}`;
        }
        window.alert(errorMessage);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.throwError)(errorMessage);
    }
};
LoginService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient },
    { type: _comandas_service__WEBPACK_IMPORTED_MODULE_0__.ComandasService },
    { type: _app_service_service__WEBPACK_IMPORTED_MODULE_1__.AppServiceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router }
];
LoginService = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Injectable)({
        providedIn: 'root'
    })
], LoginService);



/***/ }),

/***/ 7119:
/*!**********************************************************!*\
  !*** ./src/app/tab1/comandas/anadir/anadir.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AnadirComponent": () => (/* binding */ AnadirComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _anadir_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./anadir.component.html?ngResource */ 2737);
/* harmony import */ var _anadir_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./anadir.component.scss?ngResource */ 7769);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_comandas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/comandas.service */ 7914);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/app-service.service */ 5703);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 2816);










let AnadirComponent = class AnadirComponent {
    constructor(comandasService, http, modalCtrl, appservice, router, route) {
        this.comandasService = comandasService;
        this.http = http;
        this.modalCtrl = modalCtrl;
        this.appservice = appservice;
        this.router = router;
        this.route = route;
        this.data = this.comandasService.datosMesa;
        this.url = this.appservice.url;
        console.log(this.data);
        if (this.data.llevar) {
            this.ocupantes = this.data.ocupantes;
        }
        else {
            this.ocupantes = 0;
        }
        this.usuario = this.appservice.usuario;
        this.segment = 'platos';
    }
    ngOnInit() {
        console.log(this.usuario);
        this.load();
        this.generarTotal();
    }
    load() {
        this.comandasService.leerPlatos().subscribe((res) => {
            this.platos = res;
            console.log(this.platos);
        });
        this.comandasService.leerIngredientes().subscribe((res) => {
            this.ingredientes = res;
            console.log(this.ingredientes);
        });
        this.comandasService.leerBebida().subscribe((res) => {
            this.bebida = res;
            console.log(this.bebida);
        });
    }
    anadir(a) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            console.log(a);
            const colorcard = document.getElementById(a.id);
            colorcard.style.backgroundColor = 'red';
            if (this.data.platos === '' || this.data.platos === null) {
                this.data.platos = [{
                        id: a.id,
                        nombrePlato: a.nombrePlato,
                        ingredientes: a.ingredientes,
                        img: a.img,
                        precio: a.precio
                    }];
            }
            else {
                this.data.platos.push(a);
            }
            this.generarTotal();
            this.appservice.presentToast('success', 'Se ha añadido: ' + a.nombrePlato);
        });
    }
    anadirb(a) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const colorcard = document.getElementById(a.id);
            colorcard.style.backgroundColor = 'red';
            if (this.data.bebida === '' || this.data.bebida === null) {
                this.data.bebida = [{
                        id: a.id,
                        nombre: a.nombre,
                        img: a.img,
                        precio: a.precio
                    }];
            }
            else {
                this.data.bebida.push(a);
            }
            this.generarTotal();
            this.appservice.presentToast('success', 'Se ha añadido: ' + a.nombre);
        });
    }
    eliminar(a, i) {
        window.navigator.vibrate([200]);
        console.log(a);
        console.log(i);
        const colorcard = document.getElementById(a.id);
        //colorcard.style.backgroundColor = 'blue';
        this.data.platos.splice(i, i + 1);
        console.log(this.data.platos);
        this.generarTotal();
    }
    eliminarBebida(a, i) {
        window.navigator.vibrate([200]);
        this.data.bebida.splice(i, i + 1);
        console.log(this.data.bebida);
        this.generarTotal();
    }
    handleRefresh(event) {
        setTimeout(() => {
            // Any calls to load data go here
            this.load();
            event.target.complete();
        }, 2000);
    }
    ;
    cancel() {
        this.modal.dismiss(null, 'cancel');
    }
    cancel2() {
        return this.modalCtrl.dismiss(null, 'cancel');
    }
    confirm() {
        this.modal.dismiss('confirm');
    }
    confirm2() {
        return this.modalCtrl.dismiss(null, 'confirm');
    }
    guardar() {
        this.data.precioTotal = this.total;
        this.comandasService.guardarComanda(this.data, this.ocupantes).subscribe((res) => {
            this.guar = res;
            if (this.guar.valido) {
                this.appservice.presentToast('success', ('Se han guardado correctamente los cambios'));
                window.navigator.vibrate([200]);
            }
            else {
                this.appservice.presentToast('danger', ('Error al guardar los datos'));
            }
        });
    }
    guardarLlevar() {
        this.data.precioTotal = this.total;
        this.comandasService.guardarComanda(this.data, 'llevar').subscribe((res) => {
            this.guar = res;
            console.log(this.guar);
            if (this.guar.valido) {
                this.appservice.presentToast('success', ('Se han guardado correctamente los cambios'));
            }
            else {
                this.appservice.presentToast('danger', ('Error al guardar los datos'));
            }
        });
    }
    guardarDomi() {
        this.data.precioTotal = this.total;
        this.comandasService.guardarComanda(this.data, 'domi').subscribe((res) => {
            this.guar = res;
            console.log(this.guar);
            if (this.guar.valido) {
                this.appservice.presentToast('success', ('Se han guardado correctamente los cambios'));
            }
            else {
                this.appservice.presentToast('danger', ('Error al guardar los datos'));
            }
        });
    }
    segmentChanged(a) {
        console.log(a.detail.value);
        this.segment = a.detail.value;
    }
    generarTotal() {
        // eslint-disable-next-line @typescript-eslint/prefer-for-of
        let total = 0.0;
        console.log(this.data.platos !== '' && this.data.platos !== null);
        console.log(this.data.bebida !== '' && this.data.bebida !== null);
        if (this.data.platos !== '' && this.data.platos !== null) {
            for (const iterator of this.data.platos) {
                total = total + parseFloat(iterator.precio);
            }
        }
        if (this.data.bebida !== '' && this.data.bebida !== null) {
            for (const iterator of this.data.bebida) {
                total = total + parseFloat(iterator.precio);
            }
        }
        this.total = total.toFixed(2);
        console.log(this.total);
    }
    ticket() {
        this.router.navigate(['ticket', this.data.id], { relativeTo: this.route });
    }
};
AnadirComponent.ctorParameters = () => [
    { type: _services_comandas_service__WEBPACK_IMPORTED_MODULE_2__.ComandasService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_3__.AppServiceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute }
];
AnadirComponent.propDecorators = {
    modal: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonModal,] }],
    modal2: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonModal,] }]
};
AnadirComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-anadir',
        template: _anadir_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_anadir_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AnadirComponent);



/***/ }),

/***/ 4186:
/*!************************************************************************!*\
  !*** ./src/app/tab1/comandas/comanda-modal/comanda-modal.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComandaModalComponent": () => (/* binding */ ComandaModalComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _comanda_modal_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./comanda-modal.component.html?ngResource */ 8569);
/* harmony import */ var _comanda_modal_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comanda-modal.component.scss?ngResource */ 4682);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_comandas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/comandas.service */ 7914);






let ComandaModalComponent = class ComandaModalComponent {
    constructor(modalCtr, comandasService) {
        this.modalCtr = modalCtr;
        this.comandasService = comandasService;
    }
    ngOnInit() {
        console.log(this.data);
        this.load();
    }
    load() {
        this.comandasService.leerPlatos().subscribe((res) => {
            this.platos = res;
            console.log(this.platos);
        });
    }
    close() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.modalCtr.dismiss();
            return this.comandasService.datosMesa;
        });
    }
    anadir(a) {
        this.comandasService.datosMesa.push(a);
        console.log(a);
    }
};
ComandaModalComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController },
    { type: _services_comandas_service__WEBPACK_IMPORTED_MODULE_2__.ComandasService }
];
ComandaModalComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }]
};
ComandaModalComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-comanda-modal',
        template: _comanda_modal_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_comanda_modal_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ComandaModalComponent);



/***/ }),

/***/ 4241:
/*!**************************************************!*\
  !*** ./src/app/tab1/comandas/comandas.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComandasModule": () => (/* binding */ ComandasModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../tab1-routing.module */ 2580);
/* harmony import */ var _comandas_comandas_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comandas/comandas.component */ 7020);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _comanda_modal_comanda_modal_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./comanda-modal/comanda-modal.component */ 4186);
/* harmony import */ var _anadir_anadir_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./anadir/anadir.component */ 7119);
/* harmony import */ var src_app_login_login_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/login/login.component */ 8458);
/* harmony import */ var _llevar_llevar_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./llevar/llevar.component */ 4721);
/* harmony import */ var src_app_config_config_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/config/config.component */ 1497);
/* harmony import */ var _domicilio_domicilio_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./domicilio/domicilio.component */ 3025);
/* harmony import */ var _ticket_ticket_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../ticket/ticket.component */ 3654);















let ComandasModule = class ComandasModule {
};
ComandasModule = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgModule)({
        declarations: [_comandas_comandas_component__WEBPACK_IMPORTED_MODULE_1__.ComandasComponent, _comanda_modal_comanda_modal_component__WEBPACK_IMPORTED_MODULE_2__.ComandaModalComponent, _anadir_anadir_component__WEBPACK_IMPORTED_MODULE_3__.AnadirComponent, src_app_login_login_component__WEBPACK_IMPORTED_MODULE_4__.LoginComponent, _llevar_llevar_component__WEBPACK_IMPORTED_MODULE_5__.LlevarComponent,
            src_app_config_config_component__WEBPACK_IMPORTED_MODULE_6__.ConfigComponent, _domicilio_domicilio_component__WEBPACK_IMPORTED_MODULE_7__.DomicilioComponent, _ticket_ticket_component__WEBPACK_IMPORTED_MODULE_8__.TicketComponent],
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormsModule,
            _tab1_routing_module__WEBPACK_IMPORTED_MODULE_0__.Tab1PageRoutingModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_14__.HttpClientModule,
        ],
        exports: [_comandas_comandas_component__WEBPACK_IMPORTED_MODULE_1__.ComandasComponent],
    })
], ComandasModule);



/***/ }),

/***/ 7020:
/*!**************************************************************!*\
  !*** ./src/app/tab1/comandas/comandas/comandas.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComandasComponent": () => (/* binding */ ComandasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _comandas_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./comandas.component.html?ngResource */ 1826);
/* harmony import */ var _comandas_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comandas.component.scss?ngResource */ 5393);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_services_login_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/login.service */ 4120);
/* harmony import */ var _services_comandas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/comandas.service */ 7914);
/* harmony import */ var src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/app-service.service */ 5703);










let ComandasComponent = class ComandasComponent {
    constructor(applogin, comandasService, router, route, appservice, modalCtrl) {
        this.applogin = applogin;
        this.comandasService = comandasService;
        this.router = router;
        this.route = route;
        this.appservice = appservice;
        this.modalCtrl = modalCtrl;
        this.url = this.appservice.url;
        this.usuario = JSON.parse('{}');
        this.usuarios = JSON.parse('{}');
        this.segment = 'mesas';
    }
    ngAfterContentInit() {
        this.cargarUsuario();
    }
    ngOnInit() {
        this.load2();
        this.datosUsuarios();
        if (this.route.snapshot.paramMap.get('rec') !== null) {
            this.router.navigate(['/tabs/tab1']);
        }
    }
    load2() {
        this.comandasService.leerMesas().subscribe((res) => {
            this.mesas = res;
            console.log(this.mesas);
            this.convertirPlatos();
        });
    }
    convertirPlatos() {
        this.comandasService.leerPlatos().subscribe((res) => {
            this.platos = res;
            /*
            for (const key in this.mesas) {
              if (Object.prototype.hasOwnProperty.call(this.mesas, key)) {
                const element = this.mesas[key].platos;
                for (const key2 in element) {
                  if (Object.prototype.hasOwnProperty.call(element, key)) {
                    for (const key3 in this.platos) {
      
                      if (Object.prototype.hasOwnProperty.call(this.platos, key3)) {
                        const plato = this.platos[key3];
                        if (element[key2] === plato.id) {
                          element[key2] = plato.nombrePlato;
                        }
                      }
                    }
                  }
                }
              }
            }
            for (const key in this.mesas) {
              if (Object.prototype.hasOwnProperty.call(this.mesas, key)) {
                const element = this.mesas[key].platos;
                for (const key2 in element) {
                  if (Object.prototype.hasOwnProperty.call(element, key)) {
                    for (const key3 in this.platos) {
      
                      if (Object.prototype.hasOwnProperty.call(this.platos, key3)) {
                        const plato = this.platos[key3];
                        if (element[key2] === plato.id) {
                          element[key2] = plato.nombrePlato;
                        }
                      }
                    }
                  }
                }
              }
            }*/
        });
        this.cargarUsuario();
    }
    datosUsuarios() {
        this.comandasService.datosUsuarios().subscribe((res) => {
            this.usuarios = res;
            console.log(this.usuarios);
        });
    }
    load3(a, opc) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            console.log(a);
            a.llevar = opc;
            this.comandasService.datosMesa = a;
            ;
            this.router.navigate(['mesa'], { relativeTo: this.route });
        });
    }
    login() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.router.navigate(['login'], { relativeTo: this.route });
        });
    }
    handleRefresh(event) {
        setTimeout(() => {
            // Any calls to load data go here
            this.load2();
            this.cargarUsuario();
            event.target.complete();
        }, 2000);
    }
    ;
    cargarUsuario() {
        this.usuario = this.appservice.usuario;
        console.log('usuario cargad');
    }
    cancel() {
        this.modal.dismiss(null, 'cancel');
    }
    confirm() {
        this.comandasService.modObser(this.usuarios).subscribe((res) => {
            // this.usuarios = res;
            console.log(this.usuarios);
        });
        this.modal.dismiss(null, 'confirm');
    }
    onWillDismiss(event) {
        const ev = event;
        if (ev.detail.role === 'confirm') {
            this.message = `Hello, ${ev.detail.data}!`;
        }
    }
    llevar() {
        this.router.navigate(['llevar'], { relativeTo: this.route });
    }
    domicilio() {
        this.router.navigate(['domicilio'], { relativeTo: this.route });
    }
    segmentChanged(a) {
        console.log(a.detail.value);
        this.segment = a.detail.value;
    }
};
ComandasComponent.ctorParameters = () => [
    { type: src_app_services_login_service__WEBPACK_IMPORTED_MODULE_2__.LoginService },
    { type: _services_comandas_service__WEBPACK_IMPORTED_MODULE_3__.ComandasService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute },
    { type: src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_4__.AppServiceService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController }
];
ComandasComponent.propDecorators = {
    modal: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonModal,] }]
};
ComandasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-comandas',
        template: _comandas_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_comandas_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ComandasComponent);



/***/ }),

/***/ 3025:
/*!****************************************************************!*\
  !*** ./src/app/tab1/comandas/domicilio/domicilio.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DomicilioComponent": () => (/* binding */ DomicilioComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _domicilio_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./domicilio.component.html?ngResource */ 739);
/* harmony import */ var _domicilio_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./domicilio.component.scss?ngResource */ 955);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/app-service.service */ 5703);
/* harmony import */ var _services_comandas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/comandas.service */ 7914);







let DomicilioComponent = class DomicilioComponent {
    constructor(router, route, comandasService, appservice) {
        this.router = router;
        this.route = route;
        this.comandasService = comandasService;
        this.appservice = appservice;
        this.cli = JSON.parse('{}');
    }
    ngOnInit() {
        this.clientes();
    }
    siguiente() {
        if (this.nombre != null && this.apellidos != null && this.tlfn != null, this.direccion != null) {
            this.data = {
                id: this.tlfn,
                numTel: this.tlfn,
                nombreMesa: '',
                nombre: this.nombre,
                apellidos: this.apellidos,
                platos: [],
                ocupantes: 0,
                p: '',
                bebida: [],
                idusu: this.appservice.usuario.id,
                direccion: this.direccion,
                llevar: true,
                accion: 'domi'
            };
            this.comandasService.datosMesa = this.data;
            this.router.navigate(['tabs/tab1/mesa'], { replaceUrl: true });
        }
        else {
            this.appservice.presentToast('danger', 'No has introdicido todos los datos');
        }
        ;
    }
    sele(clie) {
        console.log(clie);
        this.nombre = clie.nombre;
        this.apellidos = clie.apellidos;
        this.direccion = clie.direccion;
        this.tlfn = clie.telefono;
        this.num = clie.num;
        this.localidad = clie.localidad;
    }
    guardarCliente() {
        console.log(this.nombre);
        if (this.nombre !== '' && this.apellidos !== '' && this.direccion !== ''
            && this.num !== '' && this.localidad !== '' && this.tlfn !== '') {
            const data = {
                nombre: this.nombre,
                apellidos: this.apellidos,
                direccion: this.direccion,
                num: this.num,
                localidad: this.localidad,
                tlfn: this.tlfn
            };
            this.comandasService.guardarCliente(data).subscribe((res) => {
                console.log(res);
                if (res.valido) {
                    this.appservice.presentToast('success', 'Cliente guardado');
                }
                else {
                    this.appservice.presentToast('danger', res.msg);
                }
            });
        }
        else {
            this.appservice.presentToast('danger', 'No has introducido todos los datos');
        }
        ;
    }
    clientes() {
        this.comandasService.datosClientes().subscribe((res) => {
            this.cli = res;
            console.log(this.cli);
        });
    }
    onSearchChange(evento) {
        this.busqueda = [];
        const ev = evento.detail.value;
        console.log(ev);
        console.log(this.cli);
        let i = 0;
        this.cli.forEach(element => {
            if (element.telefono.substr(0, ev.length) === ev) {
                this.busqueda[i] = element;
                i++;
            }
        });
        console.log(this.busqueda);
        if (ev === '') {
            this.busqueda = '';
        }
    }
};
DomicilioComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _services_comandas_service__WEBPACK_IMPORTED_MODULE_3__.ComandasService },
    { type: src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__.AppServiceService }
];
DomicilioComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-domicilio',
        template: _domicilio_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_domicilio_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DomicilioComponent);



/***/ }),

/***/ 4721:
/*!**********************************************************!*\
  !*** ./src/app/tab1/comandas/llevar/llevar.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LlevarComponent": () => (/* binding */ LlevarComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _llevar_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./llevar.component.html?ngResource */ 5504);
/* harmony import */ var _llevar_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./llevar.component.scss?ngResource */ 7457);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/app-service.service */ 5703);
/* harmony import */ var _services_comandas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/comandas.service */ 7914);







let LlevarComponent = class LlevarComponent {
    constructor(router, route, comandasService, appservice) {
        this.router = router;
        this.route = route;
        this.comandasService = comandasService;
        this.appservice = appservice;
        this.cli = JSON.parse('{}');
    }
    ngOnInit() {
        this.clientes();
    }
    siguiente() {
        if (this.nombre != null && this.apellidos != null && this.tlfn != null) {
            this.data = {
                id: this.tlfn,
                numTel: this.tlfn,
                nombreMesa: '',
                nombre: this.nombre,
                apellidos: this.apellidos,
                platos: [],
                ocupantes: 0,
                p: '',
                bebida: [],
                idusu: this.appservice.usuario.id,
                direccion: '',
                llevar: true,
                accion: 'llevar'
            };
            this.comandasService.datosMesa = this.data;
            this.router.navigate(['tabs/tab1/mesa'], { replaceUrl: true });
        }
        else {
            this.appservice.presentToast('danger', 'No has introdicido todos los datos');
        }
        ;
    }
    sele(clie) {
        this.nombre = clie.nombre;
        this.apellidos = clie.apellidos;
        this.direccion = clie.direccion;
        this.tlfn = clie.telefono;
    }
    clientes() {
        this.comandasService.datosClientes().subscribe((res) => {
            this.cli = res;
            console.log(this.cli);
        });
    }
    onSearchChange(evento) {
        this.busqueda = [];
        const ev = evento.detail.value;
        console.log(ev);
        console.log(this.cli);
        let i = 0;
        this.cli.forEach(element => {
            console.log(element.telefono.substr(0, ev.length));
            if (element.telefono.substr(0, ev.length) === ev) {
                this.busqueda[i] = element;
                i++;
            }
        });
        console.log(this.busqueda);
        if (ev === '') {
            this.busqueda = '';
        }
    }
    guardarCliente() {
        const data = {
            nombre: this.nombre,
            apellidos: this.apellidos,
            direccion: this.direccion,
            tlfn: this.tlfn,
        };
        this.comandasService.guardarCliente(data).subscribe((res) => {
            console.log(res);
            if (res.valido) {
                this.appservice.presentToast('success', 'Cliente guardado');
            }
            else {
                this.appservice.presentToast('danger', res.msg);
            }
        });
    }
};
LlevarComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _services_comandas_service__WEBPACK_IMPORTED_MODULE_3__.ComandasService },
    { type: src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__.AppServiceService }
];
LlevarComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-llevar',
        template: _llevar_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_llevar_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LlevarComponent);



/***/ }),

/***/ 2580:
/*!*********************************************!*\
  !*** ./src/app/tab1/tab1-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageRoutingModule": () => (/* binding */ Tab1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _config_config_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../config/config.component */ 1497);
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../login/login.component */ 8458);
/* harmony import */ var _comandas_anadir_anadir_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./comandas/anadir/anadir.component */ 7119);
/* harmony import */ var _comandas_domicilio_domicilio_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./comandas/domicilio/domicilio.component */ 3025);
/* harmony import */ var _comandas_llevar_llevar_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./comandas/llevar/llevar.component */ 4721);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tab1.page */ 6923);
/* harmony import */ var _ticket_ticket_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ticket/ticket.component */ 3654);










const routes = [
    {
        path: '',
        component: _tab1_page__WEBPACK_IMPORTED_MODULE_5__.Tab1Page,
    },
    // { path: '', redirectTo: '/first-component', pathMatch: 'full' },
    {
        path: 'mesa',
        component: _comandas_anadir_anadir_component__WEBPACK_IMPORTED_MODULE_2__.AnadirComponent,
    },
    {
        path: ':rec',
        component: _tab1_page__WEBPACK_IMPORTED_MODULE_5__.Tab1Page,
    },
    {
        path: 'mesa/ticket/:id',
        component: _ticket_ticket_component__WEBPACK_IMPORTED_MODULE_6__.TicketComponent,
    },
    {
        path: 'mesa/ticket/:id:/:rec',
        component: _ticket_ticket_component__WEBPACK_IMPORTED_MODULE_6__.TicketComponent,
    },
    {
        path: 'login',
        component: _login_login_component__WEBPACK_IMPORTED_MODULE_1__.LoginComponent,
    },
    {
        path: 'llevar',
        component: _comandas_llevar_llevar_component__WEBPACK_IMPORTED_MODULE_4__.LlevarComponent,
    },
    {
        path: 'domicilio',
        component: _comandas_domicilio_domicilio_component__WEBPACK_IMPORTED_MODULE_3__.DomicilioComponent,
    },
    {
        path: 'config',
        component: _config_config_component__WEBPACK_IMPORTED_MODULE_0__.ConfigComponent,
    },
];
let Tab1PageRoutingModule = class Tab1PageRoutingModule {
};
Tab1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule],
    })
], Tab1PageRoutingModule);



/***/ }),

/***/ 2168:
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageModule": () => (/* binding */ Tab1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 6923);
/* harmony import */ var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab1-routing.module */ 2580);
/* harmony import */ var _comandas_comandas_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./comandas/comandas.module */ 4241);








let Tab1PageModule = class Tab1PageModule {
};
Tab1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _tab1_routing_module__WEBPACK_IMPORTED_MODULE_1__.Tab1PageRoutingModule,
            _comandas_comandas_module__WEBPACK_IMPORTED_MODULE_2__.ComandasModule,
        ],
        declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page],
    })
], Tab1PageModule);



/***/ }),

/***/ 6923:
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1Page": () => (/* binding */ Tab1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab1_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page.html?ngResource */ 3852);
/* harmony import */ var _tab1_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab1.page.scss?ngResource */ 8165);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _services_app_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/app-service.service */ 5703);
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/login.service */ 4120);







let Tab1Page = class Tab1Page {
    constructor(router, applogin, route, appService) {
        this.router = router;
        this.applogin = applogin;
        this.route = route;
        this.appService = appService;
        this.user = this.appService.usuario;
        console.log(this.appService);
    }
    onLogin() {
        this.router.navigate(['login'], { relativeTo: this.route });
    }
    config() {
        this.router.navigate(['config'], { relativeTo: this.route });
    }
    onLogout() {
        this.applogin.logout();
        window.location.reload();
    }
};
Tab1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _services_login_service__WEBPACK_IMPORTED_MODULE_3__.LoginService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _services_app_service_service__WEBPACK_IMPORTED_MODULE_2__.AppServiceService }
];
Tab1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-tab1',
        template: _tab1_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tab1_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], Tab1Page);



/***/ }),

/***/ 3654:
/*!*************************************************!*\
  !*** ./src/app/tab1/ticket/ticket.component.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TicketComponent": () => (/* binding */ TicketComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ticket_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ticket.component.html?ngResource */ 6198);
/* harmony import */ var _ticket_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ticket.component.scss?ngResource */ 3476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/app-service.service */ 5703);
/* harmony import */ var _comandas_comandas_comandas_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../comandas/comandas/comandas.component */ 7020);







let TicketComponent = class TicketComponent {
    constructor(route, appService, router) {
        this.route = route;
        this.appService = appService;
        this.router = router;
        this.messageEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
        this.mesa = JSON.parse('{}');
        this.id = this.route.snapshot.paramMap.get('id');
        this.mostrar = false;
        this.bebida = [];
        this.platos = [];
    }
    ngOnInit() {
        setTimeout(this.carga, 5000);
        console.log(this.child);
        this.load();
    }
    carga() {
        document.getElementById('load').style.display = 'none';
        document.getElementById('contenido').style.display = 'block';
    }
    load() {
        this.appService.leerMesas().subscribe((res) => {
            let cont = 0;
            this.mesa = res;
            this.mesa.forEach(element => {
                if (element.id === this.id) {
                    this.mesa = res[cont];
                    //colocacion de platos
                    for (const p of this.mesa.platos) {
                        const objeto = {
                            id: p.id,
                            nombre: p.nombrePlato,
                            precio: p.precio,
                            cantidad: 1,
                        };
                        if (this.platos.length === 0) {
                            this.platos.push(objeto);
                        }
                        else {
                            if (!this.comprobar(this.platos, objeto)) {
                                this.platos.push(objeto);
                            }
                            else {
                                this.platos.forEach(i => {
                                    if (i.id === objeto.id) {
                                        i.cantidad = i.cantidad + 1;
                                    }
                                });
                            }
                        }
                    }
                    //colocacion de bebidas
                    for (const b of this.mesa.bebida) {
                        const objeto = {
                            id: b.id,
                            nombre: b.nombre,
                            precio: b.precio,
                            cantidad: 1,
                        };
                        if (this.bebida.length === 0) {
                            this.bebida.push(objeto);
                        }
                        else {
                            if (!this.comprobar(this.bebida, objeto)) {
                                this.bebida.push(objeto);
                            }
                            else {
                                this.bebida.forEach(i => {
                                    if (i.id === objeto.id) {
                                        i.cantidad = i.cantidad + 1;
                                    }
                                });
                            }
                        }
                    }
                    console.log(this.mesa.precioTotal);
                    const num = parseFloat(this.mesa.precioTotal) * 0.10;
                    this.iva = parseFloat(num.toFixed(2));
                    this.total = this.appService.trunc(parseFloat(this.mesa.precioTotal) + this.iva, 2);
                    return false;
                }
                cont++;
                //calcular total
            });
        });
        this.usuario = this.appService.getUsuario();
        console.log(this.usuario);
        const date = new Date();
        this.dia = date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
    }
    comprobar(array, nombre) {
        ;
        let retorno = false;
        for (const b2 of array) {
            if (nombre.id === b2.id) {
                retorno = true;
            }
        }
        return retorno;
    }
    pagado() {
        this.mesa.dia = this.dia;
        this.mesa.usuPa = this.usuario.id;
        this.appService.pagado(this.mesa).subscribe((res) => {
            console.log(res);
            if (res.valido) {
                window.navigator.vibrate([200]);
                this.appService.presentToast('success', 'Se ha pagado correctamente');
                this.router.navigate(['/tabs/tab1/rec']);
            }
        });
    }
};
TicketComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: src_app_services_app_service_service__WEBPACK_IMPORTED_MODULE_2__.AppServiceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router }
];
TicketComponent.propDecorators = {
    child: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ViewChild, args: [_comandas_comandas_comandas_component__WEBPACK_IMPORTED_MODULE_3__.ComandasComponent,] }],
    messageEvent: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output }]
};
TicketComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-ticket',
        template: _ticket_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ticket_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TicketComponent);



/***/ }),

/***/ 4467:
/*!***********************************************************************!*\
  !*** ./node_modules/@auth0/angular-jwt/fesm2015/auth0-angular-jwt.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JWT_OPTIONS": () => (/* binding */ JWT_OPTIONS),
/* harmony export */   "JwtHelperService": () => (/* binding */ JwtHelperService),
/* harmony export */   "JwtInterceptor": () => (/* binding */ JwtInterceptor),
/* harmony export */   "JwtModule": () => (/* binding */ JwtModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 522);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 4383);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 8784);






const JWT_OPTIONS = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.InjectionToken('JWT_OPTIONS'); // tslint:disable:no-bitwise

class JwtHelperService {
  constructor(config = null) {
    this.tokenGetter = config && config.tokenGetter || function () {};
  }

  urlBase64Decode(str) {
    let output = str.replace(/-/g, '+').replace(/_/g, '/');

    switch (output.length % 4) {
      case 0:
        {
          break;
        }

      case 2:
        {
          output += '==';
          break;
        }

      case 3:
        {
          output += '=';
          break;
        }

      default:
        {
          throw new Error('Illegal base64url string!');
        }
    }

    return this.b64DecodeUnicode(output);
  } // credits for decoder goes to https://github.com/atk


  b64decode(str) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    let output = '';
    str = String(str).replace(/=+$/, '');

    if (str.length % 4 === 1) {
      throw new Error(`'atob' failed: The string to be decoded is not correctly encoded.`);
    }

    for ( // initialize result and counters
    let bc = 0, bs, buffer, idx = 0; // get next character
    buffer = str.charAt(idx++); // character found in table? initialize bit storage and add its ascii value;
    ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer, // and if not first of each 4 characters,
    // convert the first 8 bits to one ascii character
    bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0) {
      // try to find character in table (0-63, not found => -1)
      buffer = chars.indexOf(buffer);
    }

    return output;
  }

  b64DecodeUnicode(str) {
    return decodeURIComponent(Array.prototype.map.call(this.b64decode(str), c => {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  }

  decodeToken(token = this.tokenGetter()) {
    if (!token || token === '') {
      return null;
    }

    const parts = token.split('.');

    if (parts.length !== 3) {
      throw new Error(`The inspected token doesn't appear to be a JWT. Check to make sure it has three parts and see https://jwt.io for more.`);
    }

    const decoded = this.urlBase64Decode(parts[1]);

    if (!decoded) {
      throw new Error('Cannot decode the token.');
    }

    return JSON.parse(decoded);
  }

  getTokenExpirationDate(token = this.tokenGetter()) {
    let decoded;
    decoded = this.decodeToken(token);

    if (!decoded || !decoded.hasOwnProperty('exp')) {
      return null;
    }

    const date = new Date(0);
    date.setUTCSeconds(decoded.exp);
    return date;
  }

  isTokenExpired(token = this.tokenGetter(), offsetSeconds) {
    if (!token || token === '') {
      return true;
    }

    const date = this.getTokenExpirationDate(token);
    offsetSeconds = offsetSeconds || 0;

    if (date === null) {
      return false;
    }

    return !(date.valueOf() > new Date().valueOf() + offsetSeconds * 1000);
  }

  getAuthScheme(authScheme, request) {
    if (typeof authScheme === 'function') {
      return authScheme(request);
    }

    return authScheme;
  }

}

JwtHelperService.ɵfac = function JwtHelperService_Factory(t) {
  return new (t || JwtHelperService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](JWT_OPTIONS));
};

JwtHelperService.ɵprov = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: JwtHelperService,
  factory: JwtHelperService.ɵfac
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](JwtHelperService, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable
  }], function () {
    return [{
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [JWT_OPTIONS]
      }]
    }];
  }, null);
})();

class JwtInterceptor {
  constructor(config, jwtHelper, document) {
    this.jwtHelper = jwtHelper;
    this.document = document;
    this.standardPorts = ['80', '443'];
    this.tokenGetter = config.tokenGetter;
    this.headerName = config.headerName || 'Authorization';
    this.authScheme = config.authScheme || config.authScheme === '' ? config.authScheme : 'Bearer ';
    this.allowedDomains = config.allowedDomains || [];
    this.disallowedRoutes = config.disallowedRoutes || [];
    this.throwNoTokenError = config.throwNoTokenError || false;
    this.skipWhenExpired = config.skipWhenExpired;
  }

  isAllowedDomain(request) {
    const requestUrl = new URL(request.url, this.document.location.origin); // If the host equals the current window origin,
    // the domain is allowed by default

    if (requestUrl.host === this.document.location.host) {
      return true;
    } // If not the current domain, check the allowed list


    const hostName = `${requestUrl.hostname}${requestUrl.port && !this.standardPorts.includes(requestUrl.port) ? ':' + requestUrl.port : ''}`;
    return this.allowedDomains.findIndex(domain => typeof domain === 'string' ? domain === hostName : domain instanceof RegExp ? domain.test(hostName) : false) > -1;
  }

  isDisallowedRoute(request) {
    const requestedUrl = new URL(request.url, this.document.location.origin);
    return this.disallowedRoutes.findIndex(route => {
      if (typeof route === 'string') {
        const parsedRoute = new URL(route, this.document.location.origin);
        return parsedRoute.hostname === requestedUrl.hostname && parsedRoute.pathname === requestedUrl.pathname;
      }

      if (route instanceof RegExp) {
        return route.test(request.url);
      }

      return false;
    }) > -1;
  }

  handleInterception(token, request, next) {
    const authScheme = this.jwtHelper.getAuthScheme(this.authScheme, request);
    let tokenIsExpired = false;

    if (!token && this.throwNoTokenError) {
      throw new Error('Could not get token from tokenGetter function.');
    }

    if (this.skipWhenExpired) {
      tokenIsExpired = token ? this.jwtHelper.isTokenExpired(token) : true;
    }

    if (token && tokenIsExpired && this.skipWhenExpired) {
      request = request.clone();
    } else if (token) {
      request = request.clone({
        setHeaders: {
          [this.headerName]: `${authScheme}${token}`
        }
      });
    }

    return next.handle(request);
  }

  intercept(request, next) {
    if (!this.isAllowedDomain(request) || this.isDisallowedRoute(request)) {
      return next.handle(request);
    }

    const token = this.tokenGetter(request);

    if (token instanceof Promise) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.from)(token).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.mergeMap)(asyncToken => {
        return this.handleInterception(asyncToken, request, next);
      }));
    } else {
      return this.handleInterception(token, request, next);
    }
  }

}

JwtInterceptor.ɵfac = function JwtInterceptor_Factory(t) {
  return new (t || JwtInterceptor)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](JWT_OPTIONS), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](JwtHelperService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT));
};

JwtInterceptor.ɵprov = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: JwtInterceptor,
  factory: JwtInterceptor.ɵfac
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](JwtInterceptor, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable
  }], function () {
    return [{
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [JWT_OPTIONS]
      }]
    }, {
      type: JwtHelperService
    }, {
      type: Document,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT]
      }]
    }];
  }, null);
})();

class JwtModule {
  constructor(parentModule) {
    if (parentModule) {
      throw new Error(`JwtModule is already loaded. It should only be imported in your application's main module.`);
    }
  }

  static forRoot(options) {
    return {
      ngModule: JwtModule,
      providers: [{
        provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HTTP_INTERCEPTORS,
        useClass: JwtInterceptor,
        multi: true
      }, options.jwtOptionsProvider || {
        provide: JWT_OPTIONS,
        useValue: options.config
      }, JwtHelperService]
    };
  }

}

JwtModule.ɵfac = function JwtModule_Factory(t) {
  return new (t || JwtModule)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](JwtModule, 12));
};

JwtModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: JwtModule
});
JwtModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](JwtModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule
  }], function () {
    return [{
      type: JwtModule,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Optional
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.SkipSelf
      }]
    }];
  }, null);
})();
/*
 * Public API Surface of angular-jwt
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ }),

/***/ 662:
/*!*********************************************************!*\
  !*** ./src/app/config/config.component.scss?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

module.exports = "ion-menu-button {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbmZpZy5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxNaWd1ZWwlMjBNYXJjb3NcXERlc2t0b3BcXFByb3llY3RvREFXXFxhcHAtMVxcc3JjXFxhcHBcXGNvbmZpZ1xcY29uZmlnLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtBQ0NGIiwiZmlsZSI6ImNvbmZpZy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1tZW51LWJ1dHRvbntcclxuICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuIiwiaW9uLW1lbnUtYnV0dG9uIHtcbiAgZGlzcGxheTogbm9uZTtcbn0iXX0= */";

/***/ }),

/***/ 9444:
/*!*******************************************************!*\
  !*** ./src/app/login/login.component.scss?ngResource ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = "* {\n  box-sizing: border-box;\n}\n\nhtml,\nbody {\n  background: #ecf0f3;\n}\n\nh1 {\n  margin: 0;\n  padding: 0;\n}\n\n.custom-form {\n  min-width: 300px;\n  max-width: 60%;\n  margin: 0px auto;\n  background: rgba(255, 255, 255, 0.15);\n  padding: 2rem 3rem;\n  margin: auto;\n  border-radius: 2.5rem;\n  background-color: #ecf0f3;\n  box-shadow: 13px 13px 20px #cbced1, -13px -13px 20px #ffffff;\n  color: black;\n  margin-top: 10rem;\n}\n\n.custom-form ion-input {\n  display: block;\n  margin: 2rem 0;\n  width: 100%;\n  border-radius: 0.5rem;\n  padding: 1rem;\n  border: none;\n  box-shadow: inset -5px -5px 15px rgba(255, 255, 255, 0.8), inset 5px 5px 10px rgba(0, 0, 0, 0.1);\n  border: 0 none;\n  background: #ebf5fc;\n}\n\n.custom-form button {\n  text-transform: uppercase;\n  letter-spacing: 0.15em;\n  border: none;\n  font-size: 0.875rem;\n  color: #ffffff;\n  font-weight: bold;\n  background-color: #bcd8c1;\n  width: 100%;\n  display: block;\n  padding: 0.875rem 1rem;\n  border-radius: 1.5rem;\n  box-shadow: 3px 3px 8px #b1b1b1, -3px -3px 8px #ffffff;\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXE1pZ3VlbCUyME1hcmNvc1xcRGVza3RvcFxcUHJveWVjdG9EQVdcXGFwcC0xXFxzcmNcXGFwcFxcbG9naW5cXGxvZ2luLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usc0JBQUE7QUNDRjs7QURDQTs7RUFFRSxtQkFBQTtBQ0VGOztBREFBO0VBQ0UsU0FBQTtFQUNBLFVBQUE7QUNHRjs7QUREQTtFQUNFLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EscUNBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EsNERBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUNJRjs7QURGQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxnR0FBQTtFQUVBLGNBQUE7RUFDQSxtQkFBQTtBQ0lGOztBREZBO0VBQ0UseUJBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxzQkFBQTtFQUNBLHFCQUFBO0VBQ0Esc0RBQUE7RUFDQSxlQUFBO0FDS0YiLCJmaWxlIjoibG9naW4uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIqIHtcclxuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG59XHJcbmh0bWwsXHJcbmJvZHkge1xyXG4gIGJhY2tncm91bmQ6ICNlY2YwZjM7XHJcbn1cclxuaDEge1xyXG4gIG1hcmdpbjogMDtcclxuICBwYWRkaW5nOiAwO1xyXG59XHJcbi5jdXN0b20tZm9ybSB7XHJcbiAgbWluLXdpZHRoOiAzMDBweDtcclxuICBtYXgtd2lkdGg6IDYwJTtcclxuICBtYXJnaW46IDBweCBhdXRvO1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4xNSk7XHJcbiAgcGFkZGluZzogMnJlbSAzcmVtO1xyXG4gIG1hcmdpbjogYXV0bztcclxuICBib3JkZXItcmFkaXVzOiAyLjVyZW07XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VjZjBmMztcclxuICBib3gtc2hhZG93OiAxM3B4IDEzcHggMjBweCAjY2JjZWQxLCAtMTNweCAtMTNweCAyMHB4ICNmZmZmZmY7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG4gIG1hcmdpbi10b3A6IDEwcmVtO1xyXG59XHJcbi5jdXN0b20tZm9ybSBpb24taW5wdXQge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIG1hcmdpbjogMnJlbSAwO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDAuNXJlbTtcclxuICBwYWRkaW5nOiAxcmVtO1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBib3gtc2hhZG93OiBpbnNldCAtNXB4IC01cHggMTVweCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOCksIGluc2V0IDVweCA1cHggMTBweFxyXG4gICAgICByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgYm9yZGVyOiAwIG5vbmU7XHJcbiAgYmFja2dyb3VuZDogI2ViZjVmYztcclxufVxyXG4uY3VzdG9tLWZvcm0gYnV0dG9uIHtcclxuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gIGxldHRlci1zcGFjaW5nOiAwLjE1ZW07XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIGZvbnQtc2l6ZTogMC44NzVyZW07XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2JjZDhjMTtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBwYWRkaW5nOiAwLjg3NXJlbSAxcmVtO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEuNXJlbTtcclxuICBib3gtc2hhZG93OiAzcHggM3B4IDhweCAjYjFiMWIxLCAtM3B4IC0zcHggOHB4ICNmZmZmZmY7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbiIsIioge1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xufVxuXG5odG1sLFxuYm9keSB7XG4gIGJhY2tncm91bmQ6ICNlY2YwZjM7XG59XG5cbmgxIHtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xufVxuXG4uY3VzdG9tLWZvcm0ge1xuICBtaW4td2lkdGg6IDMwMHB4O1xuICBtYXgtd2lkdGg6IDYwJTtcbiAgbWFyZ2luOiAwcHggYXV0bztcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjE1KTtcbiAgcGFkZGluZzogMnJlbSAzcmVtO1xuICBtYXJnaW46IGF1dG87XG4gIGJvcmRlci1yYWRpdXM6IDIuNXJlbTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VjZjBmMztcbiAgYm94LXNoYWRvdzogMTNweCAxM3B4IDIwcHggI2NiY2VkMSwgLTEzcHggLTEzcHggMjBweCAjZmZmZmZmO1xuICBjb2xvcjogYmxhY2s7XG4gIG1hcmdpbi10b3A6IDEwcmVtO1xufVxuXG4uY3VzdG9tLWZvcm0gaW9uLWlucHV0IHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogMnJlbSAwO1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLXJhZGl1czogMC41cmVtO1xuICBwYWRkaW5nOiAxcmVtO1xuICBib3JkZXI6IG5vbmU7XG4gIGJveC1zaGFkb3c6IGluc2V0IC01cHggLTVweCAxNXB4IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC44KSwgaW5zZXQgNXB4IDVweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgYm9yZGVyOiAwIG5vbmU7XG4gIGJhY2tncm91bmQ6ICNlYmY1ZmM7XG59XG5cbi5jdXN0b20tZm9ybSBidXR0b24ge1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBsZXR0ZXItc3BhY2luZzogMC4xNWVtO1xuICBib3JkZXI6IG5vbmU7XG4gIGZvbnQtc2l6ZTogMC44NzVyZW07XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2JjZDhjMTtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBwYWRkaW5nOiAwLjg3NXJlbSAxcmVtO1xuICBib3JkZXItcmFkaXVzOiAxLjVyZW07XG4gIGJveC1zaGFkb3c6IDNweCAzcHggOHB4ICNiMWIxYjEsIC0zcHggLTNweCA4cHggI2ZmZmZmZjtcbiAgY3Vyc29yOiBwb2ludGVyO1xufSJdfQ== */";

/***/ }),

/***/ 7769:
/*!***********************************************************************!*\
  !*** ./src/app/tab1/comandas/anadir/anadir.component.scss?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "ion-menu-button {\n  display: none;\n}\n\n.img {\n  width: 340px;\n  height: 300px;\n  background-image: no-repeat;\n  background-image: fixed;\n  background-image: center;\n  background-size: cover;\n}\n\n.fondoImagen {\n  height: 300px;\n  background-repeat: no-repeat;\n  background-attachment: fixed;\n  background-position: center center;\n  background-size: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFuYWRpci5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXE1pZ3VlbCUyME1hcmNvc1xcRGVza3RvcFxcUHJveWVjdG9EQVdcXGFwcC0xXFxzcmNcXGFwcFxcdGFiMVxcY29tYW5kYXNcXGFuYWRpclxcYW5hZGlyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0EsYUFBQTtBQ0NBOztBREVBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSwyQkFBQTtFQUNBLHVCQUFBO0VBQ0Esd0JBQUE7RUFDQSxzQkFBQTtBQ0NGOztBREVBO0VBQ0UsYUFBQTtFQUNBLDRCQUFBO0VBQ0EsNEJBQUE7RUFDQSxrQ0FBQTtFQUNBLHNCQUFBO0FDQ0YiLCJmaWxlIjoiYW5hZGlyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW1lbnUtYnV0dG9ue1xyXG5kaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG4uaW1nIHtcclxuICB3aWR0aDogMzQwcHg7XHJcbiAgaGVpZ2h0OiAzMDBweDtcclxuICBiYWNrZ3JvdW5kLWltYWdlOiBuby1yZXBlYXQ7XHJcbiAgYmFja2dyb3VuZC1pbWFnZTogZml4ZWQ7XHJcbiAgYmFja2dyb3VuZC1pbWFnZTogY2VudGVyO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbn1cclxuXHJcbi5mb25kb0ltYWdlbiB7XHJcbiAgaGVpZ2h0OiAzMDBweDtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIGJhY2tncm91bmQtYXR0YWNobWVudDogZml4ZWQ7XHJcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyIGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG59XHJcbiIsImlvbi1tZW51LWJ1dHRvbiB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5pbWcge1xuICB3aWR0aDogMzQwcHg7XG4gIGhlaWdodDogMzAwcHg7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1pbWFnZTogZml4ZWQ7XG4gIGJhY2tncm91bmQtaW1hZ2U6IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuLmZvbmRvSW1hZ2VuIHtcbiAgaGVpZ2h0OiAzMDBweDtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgYmFja2dyb3VuZC1hdHRhY2htZW50OiBmaXhlZDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyIGNlbnRlcjtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn0iXX0= */";

/***/ }),

/***/ 4682:
/*!*************************************************************************************!*\
  !*** ./src/app/tab1/comandas/comanda-modal/comanda-modal.component.scss?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb21hbmRhLW1vZGFsLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 5393:
/*!***************************************************************************!*\
  !*** ./src/app/tab1/comandas/comandas/comandas.component.scss?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

module.exports = "#centro {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbWFuZGFzLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcTWlndWVsJTIwTWFyY29zXFxEZXNrdG9wXFxQcm95ZWN0b0RBV1xcYXBwLTFcXHNyY1xcYXBwXFx0YWIxXFxjb21hbmRhc1xcY29tYW5kYXNcXGNvbWFuZGFzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNBRiIsImZpbGUiOiJjb21hbmRhcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4jY2VudHJve1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlclxyXG59XHJcbiIsIiNjZW50cm8ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn0iXX0= */";

/***/ }),

/***/ 955:
/*!*****************************************************************************!*\
  !*** ./src/app/tab1/comandas/domicilio/domicilio.component.scss?ngResource ***!
  \*****************************************************************************/
/***/ ((module) => {

module.exports = ".col {\n  display: flex;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRvbWljaWxpby5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXE1pZ3VlbCUyME1hcmNvc1xcRGVza3RvcFxcUHJveWVjdG9EQVdcXGFwcC0xXFxzcmNcXGFwcFxcdGFiMVxcY29tYW5kYXNcXGRvbWljaWxpb1xcZG9taWNpbGlvLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FDQ0YiLCJmaWxlIjoiZG9taWNpbGlvLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbiIsIi5jb2wge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufSJdfQ== */";

/***/ }),

/***/ 7457:
/*!***********************************************************************!*\
  !*** ./src/app/tab1/comandas/llevar/llevar.component.scss?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "ion-menu-button {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxsZXZhci5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXE1pZ3VlbCUyME1hcmNvc1xcRGVza3RvcFxcUHJveWVjdG9EQVdcXGFwcC0xXFxzcmNcXGFwcFxcdGFiMVxcY29tYW5kYXNcXGxsZXZhclxcbGxldmFyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0EsYUFBQTtBQ0NBIiwiZmlsZSI6ImxsZXZhci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1tZW51LWJ1dHRvbntcclxuZGlzcGxheTogbm9uZTtcclxufVxyXG4iLCJpb24tbWVudS1idXR0b24ge1xuICBkaXNwbGF5OiBub25lO1xufSJdfQ== */";

/***/ }),

/***/ 8165:
/*!************************************************!*\
  !*** ./src/app/tab1/tab1.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWIxLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 3476:
/*!**************************************************************!*\
  !*** ./src/app/tab1/ticket/ticket.component.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "#contenido {\n  display: none;\n  background-color: #fff;\n  color: #000;\n  border: 1px solid;\n}\n\n#bordes {\n  border-bottom: 1px solid;\n  border-top: 1px solid;\n}\n\nion-col {\n  display: flex;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRpY2tldC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcTWlndWVsJTIwTWFyY29zXFxEZXNrdG9wXFxQcm95ZWN0b0RBV1xcYXBwLTFcXHNyY1xcYXBwXFx0YWIxXFx0aWNrZXRcXHRpY2tldC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBQ0NBOztBREVBO0VBQ0Usd0JBQUE7RUFDQSxxQkFBQTtBQ0NGOztBRENBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0FDRUYiLCJmaWxlIjoidGlja2V0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2NvbnRlbmlkb3tcclxuZGlzcGxheTogbm9uZTtcclxuYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuY29sb3I6ICMwMDA7XHJcbmJvcmRlcjoxcHggc29saWRcclxufVxyXG5cclxuI2JvcmRlcyB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkO1xyXG4gIGJvcmRlci10b3A6IDFweCBzb2xpZDtcclxufVxyXG5pb24tY29sIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcbiIsIiNjb250ZW5pZG8ge1xuICBkaXNwbGF5OiBub25lO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBjb2xvcjogIzAwMDtcbiAgYm9yZGVyOiAxcHggc29saWQ7XG59XG5cbiNib3JkZXMge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQ7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZDtcbn1cblxuaW9uLWNvbCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufSJdfQ== */";

/***/ }),

/***/ 8868:
/*!*********************************************************!*\
  !*** ./src/app/config/config.component.html?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n      <ion-back-button>Mesa</ion-back-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding \">\n\n  <ion-item>\n    <ion-label position=\"floating\">Ip del servidor</ion-label>\n    <ion-input placeholder=\"Enter text\"></ion-input>\n  </ion-item>\n  <ion-button id=\"open-modal\" expand=\"block\" shape=\"round\">\n    Asignar mesas\n  </ion-button>\n  <!--Añadir mas contenido-->\n  <ion-modal trigger=\"open-modal\" (willDismiss)=\"onWillDismiss($event)\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-buttons slot=\"start\">\n            <ion-button (click)=\"cancel()\">Cancel</ion-button>\n          </ion-buttons>\n          <ion-title>Welcome</ion-title>\n          <ion-buttons slot=\"end\">\n            <ion-button (click)=\"confirm()\" [strong]=\"true\">Confirm</ion-button>\n          </ion-buttons>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content class=\"ion-padding\">\n        <ion-item *ngFor=\"let mesa of mesas;let i= index\">\n          <ion-grid>\n            <ion-row>\n              <ion-col size=\"4\">\n                <p *ngIf=\"mesa.nombreMesa!==null\">{{mesa.nombreMesa}}</p>\n                <p *ngIf=\"mesa.nombreMesa===null\">{{mesa.numTel}}<p>\n                  </ion-col>\n                  <ion-col size=\"3\">\n                    <p>{{usuarios[mesa.idusu-1].nombre}}</p>\n                  </ion-col>\n                  <ion-col size=\"5\">\n                    <ion-item>\n                      <ion-select [(ngModel)]=\"usuSelect[i+1]\">\n                        <ion-select-option *ngFor=\"let usu of usuarios\"\n                          [value]=\"usu.id\">{{usu.nombre}}</ion-select-option>\n                      </ion-select>\n                    </ion-item>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n\n\n\n            </ion-item>\n          </ion-content>\n        </ng-template>\n      </ion-modal>\n    </ion-content>\n";

/***/ }),

/***/ 2010:
/*!*******************************************************!*\
  !*** ./src/app/login/login.component.html?ngResource ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = "\n<ion-grid>\n  <ion-card>\n    <ion-row id=\"centro\">\n      <ion-col size=\"3\">\n      </ion-col>\n      <ion-col size=\"6\">\n        <img src=\"../../../../assets/logos/logo2.png\" alt=\"\">\n      </ion-col>\n      <ion-col size=\"3\">\n      </ion-col>\n    </ion-row>\n    <ion-item>\n      <ion-label>Usuario</ion-label>\n      <ion-input [(ngModel)]=\"nombre\" type=\"text\"></ion-input>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>Contraseña</ion-label>\n      <ion-input [(ngModel)]=\"contra\" type=\"password\"></ion-input>\n    </ion-item>\n    <ion-button (click)=\"onLogin()\" expand=\"block\" fill=\"clear\" shape=\"round\">\n      Acceder\n    </ion-button>\n\n  </ion-card>\n</ion-grid>\n";

/***/ }),

/***/ 2737:
/*!***********************************************************************!*\
  !*** ./src/app/tab1/comandas/anadir/anadir.component.html?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n      <ion-back-button>Mesa</ion-back-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\" id=\"fondo\">\n\n  <ion-grid>\n    <ion-row id=\"centro\">\n      <ion-col size=\"3\">\n      </ion-col>\n      <ion-col size=\"6\">\n        <img src=\"../../../../assets/logos/logo2.png\" alt=\"\">\n      </ion-col>\n      <ion-col size=\"3\">\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"handleRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-list *ngIf=\"data.llevar\">\n    <ion-item>\n      <ion-label position=\"stacked\">Nombre y Apellidos</ion-label>\n      <ion-input [disabled]=\"true\">{{data.nombre}} {{data.apellidos}}</ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Numero tlf cliente</ion-label>\n      <ion-input [disabled]=\"true\"> {{data.numTel}} </ion-input>\n    </ion-item>\n    <ion-item *ngIf=\"data.accion==='domi'\">\n      <ion-label>Dirección</ion-label>\n      <ion-textarea [disabled]=\"true\"> {{data.direccion}} </ion-textarea>\n    </ion-item>\n\n  </ion-list>\n\n  <ion-list *ngIf=\"!data.llevar\">\n    <ion-item>\n      <ion-label position=\"stacked\"> Número de mesa </ion-label>\n      <ion-input [disabled]=\"true\"> {{data.nombreMesa}} </ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Comensales</ion-label>\n      <ion-input [(ngModel)]=\"ocupantes\" type=\"number\"></ion-input>\n    </ion-item>\n\n  </ion-list>\n\n  <ion-card>\n\n    <ion-card-header>\n      <ion-card-title>Bebida</ion-card-title>\n    </ion-card-header>\n    <ion-card-content *ngIf=\"data.bebida!==''\">\n      <ion-row *ngFor=\"let b of data.bebida;index as i\">\n        <ion-col class=\"centro\" size=\"8\">\n          <p>{{b.nombre}}</p>\n        </ion-col>\n        <ion-col size=\"2\" class=\"centro\">\n          <p>{{b.precio}}</p>\n        </ion-col>\n        <ion-col class=\"centro\" size=\"2\">\n          <ion-tab-button (click)=\"eliminarBebida(b,i)\">\n            <ion-icon name=\"trash-outline\"></ion-icon>\n            <ion-label position=\"stacked\">Eliminar</ion-label>\n          </ion-tab-button>\n        </ion-col>\n      </ion-row>\n    </ion-card-content>\n\n    <ion-card-header>\n      <ion-card-title>Platos\n\n      </ion-card-title>\n    </ion-card-header>\n    <ion-card-content *ngIf=\"data.platos!==''\">\n\n      <ion-row *ngFor=\"let p of data.platos;index as i\">\n        <ion-col class=\"centro\" size=\"8\">\n          <p>{{p.nombrePlato}}</p>\n        </ion-col>\n        <ion-col size=\"2\" class=\"centro\">\n          <p>{{p.precio}}</p>\n        </ion-col>\n        <ion-col class=\"centro\" size=\"2\">\n          <ion-tab-button (click)=\"eliminar(p,i)\">\n            <ion-icon name=\"trash-outline\"></ion-icon>\n            <ion-label position=\"stacked\">Eliminar</ion-label>\n          </ion-tab-button>\n        </ion-col>\n      </ion-row>\n    </ion-card-content>\n    <ion-item>\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"9\">Total</ion-col>\n          <ion-col size=\"3\">{{total}}€</ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-item>\n  </ion-card>\n\n\n  <ion-button expand=\"block\" id=\"open-modalM\">Modificar</ion-button>\n\n  <ion-button expand=\"block\" (click)=\"guardarLlevar()\"\n    *ngIf=\"data.accion ==='llevar'\">\n    Guardar\n  </ion-button>\n  <ion-button expand=\"block\" (click)=\"guardarDomi()\"\n    *ngIf=\"data.accion==='domi'\">\n    Guardar\n  </ion-button>\n\n  <ion-button expand=\"block\" (click)=\"guardar()\" *ngIf=\"!data.llevar\">Guardar</ion-button>\n  <ion-button expand=\"block\" (click)=\"ticket()\">\n    Generar ticket\n\n  </ion-button>\n\n\n  <ion-modal trigger=\"open-modalM\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-buttons slot=\"start\">\n            <ion-button (click)=\"cancel2()\">\n              <ion-icon name=\"close-outline\"></ion-icon>\n            </ion-button>\n          </ion-buttons>\n          <ion-title>Productos</ion-title>\n          <ion-buttons slot=\"end\">\n            <ion-button (click)=\"confirm2()\" [strong]=\"true\"><ion-icon\n                name=\"checkmark-outline\"></ion-icon>\n            </ion-button>\n          </ion-buttons>\n\n        </ion-toolbar>\n        <ion-segment (ionChange)=\"segmentChanged($event)\" value=\"platos\">\n          <ion-segment-button value=\"platos\">\n            Platos\n          </ion-segment-button>\n          <ion-segment-button value=\"bebida\">\n            Bebidas\n          </ion-segment-button>\n        </ion-segment>\n      </ion-header>\n      <ion-content class=\"ion-padding\">\n        <div *ngIf=\"segment==='bebida'\">\n          <ion-card *ngFor=\"let b of bebida;index as i\" id=\"{{b.id}}\"\n            style=\"background-image: linear-gradient(rgba(0, 0, 0), rgba(0, 0,\n            0,\n            0.5)), url('{{url}}/proyectoDaw{{b.img}}');\"\n            class=\"fondoImagen\">\n            <ion-card-header>\n\n              <ion-grid>\n                <ion-row>\n                  <ion-col size=\"10\">\n                    <ion-card-title>{{b.nombre}} - {{b.precio}}€</ion-card-title>\n                  </ion-col>\n                  <ion-col size=\"2\">\n                    <ion-fab-button (click)=\"anadirb(b)\">\n                      <ion-icon name=\"add\"></ion-icon>\n                    </ion-fab-button>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n            </ion-card-header>\n            <ion-card-content>\n            </ion-card-content>\n          </ion-card>\n        </div>\n        <div *ngIf=\"segment==='platos'\">\n\n\n          <ion-card *ngFor=\"let p of platos\" id=\"{{p.id}}\"\n            style=\"background-image:linear-gradient(rgba(0, 0, 0), rgba(0, 0, 0,\n            0.5)), url('{{url}}/proyectoDaw{{p.img}}');\"\n            class=\"fondoImagen\">\n\n            <ion-card-header>\n\n              <ion-grid>\n                <ion-row>\n                  <ion-col size=\"8\">\n                    <ion-card-title>{{p.nombrePlato}} {{p.precio}}€</ion-card-title>\n                  </ion-col>\n                  <ion-col size=\"4\">\n                    <ion-fab-button (click)=\"anadir(p)\">\n                      <ion-icon name=\"add\"></ion-icon>\n                    </ion-fab-button>\n\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n\n              <ion-card-subtitle>Ingredientes:</ion-card-subtitle>\n            </ion-card-header>\n            <ion-card-content>\n              <ion-grid>\n\n                <ion-row>\n                  <ion-chip *ngFor=\"let ing of p.ingredientes\">\n                    <ion-label position=\"stacked\">{{ing.nombre}}</ion-label>\n                    <ion-icon name=\"trash-outline\"></ion-icon>\n                  </ion-chip>\n\n                </ion-row>\n              </ion-grid>\n\n\n            </ion-card-content>\n\n          </ion-card>\n        </div>\n\n      </ion-content>\n\n    </ng-template>\n  </ion-modal>\n\n\n</ion-content>\n";

/***/ }),

/***/ 8569:
/*!*************************************************************************************!*\
  !*** ./src/app/tab1/comandas/comanda-modal/comanda-modal.component.html?ngResource ***!
  \*************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n    </ion-buttons>\n    <ion-title>Mesa {{data[1]}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"close()\">Cerrar</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content class=\"ion-padding\">\n\n  <ion-card *ngFor=\"let p of platos\" (click)=\"anadir(p)\">\n    <ion-card-header>\n      <ion-card-title>{{p[1]}}</ion-card-title>\n      <ion-card-subtitle>Card Subtitlea</ion-card-subtitle>\n    </ion-card-header>\n    <ion-card-content>\n\n    </ion-card-content>\n  </ion-card>\n\n\n\n\n</ion-content>";

/***/ }),

/***/ 1826:
/*!***************************************************************************!*\
  !*** ./src/app/tab1/comandas/comandas/comandas.component.html?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

module.exports = "<ion-refresher slot=\"fixed\" (ionRefresh)=\"handleRefresh($event)\">\n  <ion-refresher-content></ion-refresher-content>\n</ion-refresher>\n<div *ngIf=\"usuario.nombre\">\n\n  <ion-item>\n    <ion-avatar slot=\"start\">\n      <img [src]=\"url+'/proyectoDaw'+usuario.img\" alt=\"\">\n    </ion-avatar>\n    <ion-grid>\n      <ion-row>\n        <ion-label>Nombre: {{usuario.nombre}}</ion-label>\n      </ion-row>\n      <ion-row>\n        <ion-label>Tipo de usuario: {{usuario.rol}}</ion-label>\n      </ion-row>\n    </ion-grid>\n  </ion-item>\n\n\n  <ion-grid>\n    <ion-row id=\"centro\">\n      <ion-col size=\"3\">\n        <ion-fab-button (click)=\"llevar()\">\n          <ion-icon name=\"car-sport-outline\"></ion-icon>\n        </ion-fab-button>\n      </ion-col>\n      <ion-col size=\"6\">\n        <img src=\"../../../../assets/logos/logo2.png\" alt=\"\">\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-fab-button (click)=\"domicilio()\">\n          <ion-icon name=\"home-outline\"></ion-icon>\n        </ion-fab-button>\n\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  <ion-card color=\"secondary\">\n    <ion-card-header>\n      <ion-card-title>\n        Observaciones del día\n      </ion-card-title>\n    </ion-card-header>\n    <ion-card-content>\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"10\">\n            <ion-label>\n\n              <ion-textarea type=\"text\" [autoGrow]=\"true\">{{usuario.obs}}</ion-textarea>\n            </ion-label>\n          </ion-col>\n          <ion-col size=\"2\">\n            <ion-fab-button *ngIf=\"usuario.rol==='admin'\"\n              id=\"open-modal\" expand=\"block\">\n              <ion-icon name=\"add-outline\"></ion-icon>\n            </ion-fab-button>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-card-content>\n\n  </ion-card>\n\n\n  <ion-segment (ionChange)=\"segmentChanged($event)\" value=\"mesas\">\n    <ion-segment-button value=\"llevar\">\n      <ion-label>LLevar</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"mesas\">\n      <ion-label>Mesas</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"domi\">\n      <ion-label>Domicilio</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n\n  <div *ngFor=\"let mesa of mesas;index as i\">\n\n    <div *ngIf=\"(usuario.rol ==='admin' || mesa.idusu===usuario.id )\">\n      <ion-card (click)=\"load3(mesa,true)\" *ngIf=\" segment==='llevar' &&\n        mesa.accion ==='llevar'\" color=\"dark\">\n        <ion-card-header>\n          <ion-card-title>{{mesa.numTel}}\n            <ion-icon name=\"car-sport-outline\"></ion-icon>\n          </ion-card-title>\n          <ion-card-subtitle>{{mesa.nombre}} {{mesa.apellidos}}</ion-card-subtitle>\n        </ion-card-header>\n        <ion-card-content>\n          <h1>Bebidas</h1>\n          <p *ngFor=\"let b of mesa.bebida\">{{b.nombre }} </p>\n          <h1>Platos</h1>\n          <p *ngFor=\"let platos of mesa.platos\">{{platos.nombrePlato }} </p>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n    <div *ngIf=\"usuario.rol ==='admin' || mesa.idusu===usuario.id\">\n      <ion-card (click)=\"load3(mesa,false)\" *ngIf=\"segment==='mesas' &&\n        (mesa.accion===null|| mesa.accion==='') && mesa.nombreMesa!==null\">\n        <ion-card-header>\n          <ion-card-title>{{mesa.nombreMesa}}\n            <ion-icon name=\"restaurant-outline\"></ion-icon>\n          </ion-card-title>\n          <ion-card-subtitle>{{mesa.ocupantes}} ocupantes</ion-card-subtitle>\n          <ion-card-subtitle>Usuario asignado {{mesa.idusu}}</ion-card-subtitle>\n        </ion-card-header>\n        <ion-card-content>\n          <h1>Bebidas</h1>\n          <p *ngFor=\"let b of mesa.bebida\">{{b.nombre }} </p>\n          <h1>Platos</h1>\n          <p *ngFor=\"let platos of mesa.platos\">{{platos.nombrePlato }} </p>\n        </ion-card-content>\n      </ion-card>\n    </div>\n\n    <div *ngIf=\"(usuario.rol ==='admin' || mesa.idusu===usuario.id )\">\n      <ion-card (click)=\"load3(mesa,true)\" *ngIf=\" segment==='domi' &&\n        mesa.accion ==='domi'\" color=\"medium\">\n        <ion-card-header>\n          <ion-card-title>{{mesa.numTel}} <ion-icon name=\"home-outline\"></ion-icon></ion-card-title>\n          <ion-card-subtitle>{{mesa.nombre}} {{mesa.apellidos}}</ion-card-subtitle>\n        </ion-card-header>\n        <ion-card-content>\n          <h1>Bebidas</h1>\n          <p *ngFor=\"let b of mesa.bebida\">{{b.nombre }} </p>\n          <h1>Platos</h1>\n          <p *ngFor=\"let platos of mesa.platos\">{{platos.nombrePlato }} </p>\n        </ion-card-content>\n      </ion-card>\n    </div>\n  </div>\n\n\n</div>\n<!--Si no está registrado-->\n<div *ngIf=\"!usuario.nombre\">\n  <ion-grid>\n    <ion-row id=\"centro\">\n      <ion-col size=\"3\">\n      </ion-col>\n      <ion-col size=\"6\">\n        <img src=\"../../../../assets/logos/logo2.png\" alt=\"\">\n      </ion-col>\n      <ion-col size=\"3\">\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-card>\n    <ion-card-content>\n      <p>Para Ver el contenido necesitas registrarte</p>\n      <ion-button expand=\"block\" (click)=\"login()\">\n        Registro\n      </ion-button>\n      <img alt=\"Silhouette of a person's head\"\n        src=\"../../../../assets/img/img1.png\" />\n\n    </ion-card-content>\n  </ion-card>\n</div>\n\n<!--Modal de observaciones-->\n\n<ion-modal trigger=\"open-modal\">\n  <ng-template>\n    <ion-header>\n      <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-button (click)=\"cancel()\">Cancelar</ion-button>\n        </ion-buttons>\n        <ion-title>Observaciones</ion-title>\n        <ion-buttons slot=\"end\">\n          <ion-button (click)=\"confirm()\" [strong]=\"true\">Confirmar</ion-button>\n        </ion-buttons>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content class=\"ion-padding\">\n      <ion-item *ngFor=\"let usu of usuarios\">\n        <ion-label position=\"stacked\">{{usu.nombre}} - {{usu.id}}</ion-label>\n        <ion-textarea type=\"text\" [autoGrow]=\"true\" [(ngModel)]=\"usu.obs\"></ion-textarea>\n      </ion-item>\n\n    </ion-content>\n  </ng-template>\n</ion-modal>\n";

/***/ }),

/***/ 739:
/*!*****************************************************************************!*\
  !*** ./src/app/tab1/comandas/domicilio/domicilio.component.html?ngResource ***!
  \*****************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n      <ion-back-button>Mesa</ion-back-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding \">\n\n  <ion-searchbar placeholder=\"Buscar Cliente\" inputmode=\"decimal\" type=\"decimal\"\n    (ionChange)=\"onSearchChange($event)\"\n    [debounce]=\"250\" showCancelButton=\"always\"></ion-searchbar>\n  <ion-card *ngIf=\"busqueda\">\n    <ion-card-content>\n      <ion-grid>\n        <ion-row *ngFor=\"let b of busqueda\">\n          <ion-col size=\"10\" class=\"col\">\n            <p>{{b.nombre}} {{b.apellidos}},\n              {{b.direccion}} {{b.localidad}} </p></ion-col>\n          <ion-col size=\"2\">\n            <ion-fab-button (click)=\"sele(b)\">\n              <ion-icon name=\"add\"></ion-icon>\n            </ion-fab-button>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n    </ion-card-content>\n  </ion-card>\n  <ion-list [inset]=\"true\">\n    <ion-item>\n      <ion-label position=\"stacked\">Nombre</ion-label>\n      <ion-input [clearInput]=\"true\" placeholder=\"Introduce el nombre\"\n        [(ngModel)]=\"nombre\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Apellidos</ion-label>\n      <ion-input [clearInput]=\"true\" placeholder=\"Introduce los apellidos\"\n        [(ngModel)]=\"apellidos\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Teléfono</ion-label>\n      <ion-input [clearInput]=\"true\" placeholder=\"Introduce el teléfono\"\n        [(ngModel)]=\"tlfn\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Dirección</ion-label>\n      <ion-input [clearInput]=\"true\" placeholder=\"Introduce la dirección\"\n        [(ngModel)]=\"direccion\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Número</ion-label>\n      <ion-input [clearInput]=\"true\" placeholder=\"Introduce el número\"\n        [(ngModel)]=\"num\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Localidad</ion-label>\n      <ion-input [clearInput]=\"true\" placeholder=\"Introduce la localidad\"\n        [(ngModel)]=\"localidad\"></ion-input>\n    </ion-item>\n  </ion-list>\n  <ion-button (click)=\"guardarCliente()\" expand=\"block\" shape=\"round\">\n    Guardar cliente\n  </ion-button>\n\n  <ion-button (click)=\"siguiente()\" expand=\"block\">\n    <ion-icon slot=\"start\" name=\"add\"></ion-icon>\n    Siguiente\n  </ion-button>\n</ion-content>\n";

/***/ }),

/***/ 5504:
/*!***********************************************************************!*\
  !*** ./src/app/tab1/comandas/llevar/llevar.component.html?ngResource ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n      <ion-back-button>Mesa</ion-back-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding \">\n\n  <ion-searchbar placeholder=\"Buscar Cliente\" inputmode=\"decimal\" type=\"decimal\"\n    (ionChange)=\"onSearchChange($event)\"\n    [debounce]=\"250\" showCancelButton=\"always\"></ion-searchbar>\n  <ion-card *ngIf=\"busqueda\">\n    <ion-card-content>\n      <ion-grid>\n        <ion-row *ngFor=\"let b of busqueda\">\n          <ion-col size=\"10\" class=\"col\">\n            <p>{{b.nombre}} {{b.apellidos}},\n              {{b.direccion}} {{b.localidad}} </p></ion-col>\n          <ion-col size=\"2\">\n            <ion-fab-button (click)=\"sele(b)\">\n              <ion-icon name=\"add\"></ion-icon>\n            </ion-fab-button>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n    </ion-card-content>\n  </ion-card>\n\n  <ion-list [inset]=\"true\">\n    <ion-item>\n      <ion-label position=\"stacked\">Nombre</ion-label>\n      <ion-input [clearInput]=\"true\" placeholder=\"Introduce el nombre\"\n        [(ngModel)]=\"nombre\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Apellidos</ion-label>\n      <ion-input [clearInput]=\"true\" placeholder=\"Introduce los apellidos\"\n        [(ngModel)]=\"apellidos\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"stacked\">Teléfono</ion-label>\n      <ion-input [clearInput]=\"true\" placeholder=\"Introduce el teléfono\"\n        [(ngModel)]=\"tlfn\"></ion-input>\n    </ion-item>\n  </ion-list>\n\n  <ion-button (click)=\"guardarCliente()\" expand=\"block\" shape=\"round\">\n    Guardar cliente\n  </ion-button>\n\n  <ion-button (click)=\"siguiente()\" expand=\"block\">\n    <ion-icon slot=\"start\" name=\"add\"></ion-icon>\n    Siguiente\n  </ion-button>\n</ion-content>\n";

/***/ }),

/***/ 3852:
/*!************************************************!*\
  !*** ./src/app/tab1/tab1.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button>\n\n      </ion-menu-button>\n    </ion-buttons>\n    <ion-title>Menu</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content [fullscreen]=\"true\">\n\n  <ion-menu contentId=\"main-content\">\n    <ion-header>\n      <ion-toolbar>\n        <ion-title>Menu Content</ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content class=\"ion-padding\">\n      <ion-button (click)=\"onLogin()\" expand=\"block\">login</ion-button>\n      <ion-button (click)=\"onLogout()\" expand=\"block\">Cerrar Sesion</ion-button>\n      <!--<ion-button *ngIf=\"user.rol==='admin'\"  (click)=\"config()\" expand=\"block\">Configuración</ion-button>-->\n      <ion-button (click)=\"config()\" expand=\"block\">Configuración</ion-button>\n    </ion-content>\n  </ion-menu>\n\n  <div class=\"ion-page\" id=\"main-content\">\n\n\n\n  </div>\n  <app-comandas></app-comandas>\n</ion-content>\n";

/***/ }),

/***/ 6198:
/*!**************************************************************!*\
  !*** ./src/app/tab1/ticket/ticket.component.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n      <ion-back-button>ticket</ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-progress-bar type=\"indeterminate\" id=\"load\"></ion-progress-bar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n\n  <ion-fab slot=\"fixed\" vertical=\"top\" horizontal=\"start\">\n    <ion-fab-button (click)=\"pagado()\">\n      <ion-icon name=\"journal-outline\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <div id=\"contenido\">\n\n    <ion-grid>\n      <ion-row id=\"centro\">\n        <ion-col size=\"3\">\n        </ion-col>\n        <ion-col size=\"6\">\n          <img src=\"../../../../assets/logos/logo2.png\" alt=\"\">\n        </ion-col>\n        <ion-col size=\"3\">\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n    <ion-grid fixed>\n      <ion-row>\n        <ion-col size=\"6\">Id ticket:</ion-col>\n        <ion-col size=\"6\">{{mesa.id}}</ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"6\">Tipo:</ion-col>\n        <ion-col size=\"6\">{{mesa.accion}}</ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"6\">Le atendió:</ion-col>\n        <ion-col size=\"6\">{{usuario.nombre}}</ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"6\">Fecha</ion-col>\n        <ion-col size=\"6\">{{dia}}</ion-col>\n      </ion-row>\n    </ion-grid>\n    <!--Cabecera-->\n\n    <ion-grid fixed>\n      <ion-row id=\"bordes\">\n        <ion-col size=\"4\">\n          <p>Producto</p>\n        </ion-col>\n        <ion-col size=\"4\">\n          <p>Cantidad</p>\n        </ion-col>\n        <ion-col size=\"4\">\n          <p>Precio</p>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n    <!--Contenido-->\n    <div *ngFor=\" let m of bebida\">\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"4\">\n            <p>{{m.nombre}}</p>\n          </ion-col>\n          <ion-col size=\"4\">\n            <p>X {{m.cantidad}}</p>\n          </ion-col>\n          <ion-col size=\"4\">\n            <p>{{m.precio}}</p>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n    </div>\n    <div *ngFor=\" let m of platos\">\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"4\">\n            <p>{{m.nombre}}</p>\n          </ion-col>\n          <ion-col size=\"4\">\n            <p>X {{m.cantidad}}</p>\n          </ion-col>\n          <ion-col size=\"4\">\n            <p>{{m.precio}}</p>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n    </div>\n    <!--Total-->\n    <ion-grid fixed id=\"bordes\">\n      <ion-row>\n        <ion-col size=\"8\" pull=\"2\">Facturación neta</ion-col>\n        <ion-col size=\"4\">{{mesa.precioTotal}}</ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size=\"8\" pull=\"2\">10% IVA</ion-col>\n        <ion-col size=\"4\">{{iva}}</ion-col>\n      </ion-row>\n      <ion-row id=\"bordes\">\n        <ion-col size=\"8\" pull=\"2\">Total</ion-col>\n        <ion-col size=\"4\">{{total}}</ion-col>\n      </ion-row>\n    </ion-grid>\n\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab1_tab1_module_ts.js.map